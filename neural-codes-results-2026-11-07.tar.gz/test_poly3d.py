"""Tests for poly3d.py. Run: python3 test_poly3d.py"""
import glob, json
import poly
from poly3d import check, search, DIAG3, AX3
from polysat_nd import search as sat_search
from neuralcodes import parse_short, has_local_obstruction


def ok(name, cond):
    print(("PASS  " if cond else "FAIL  ") + name, flush=True)
    assert cond, name


T3 = parse_short("135 246 12 34 56 1 2 3 4 5 6".split())

# 1. referee agrees with the 2D referee on real 2D drawings (dimension-free code path)
certs = sorted(glob.glob("certificates/C5-0*.json"))[:12]
codes = {c["id"]: c for c in json.load(open("jeffs_96_codes.json"))["codes"]}
agree = True
for f in certs:
    d = json.load(open(f))
    if "regions" not in d:
        continue
    cert = poly.oct_to_poly(d["regions"])
    a = poly.check(codes[d["id"]]["codewords"], cert, poly.DIRS4)[0]
    b = check(codes[d["id"]]["codewords"], cert, poly.DIRS4)[0]
    agree &= (a == b == True)
ok("3D referee agrees with the 2D referee on 12 real octagon drawings", agree)

# 2. referee rejects a broken drawing (shrink one region so a codeword disappears)
d = json.load(open(certs[0]))
cert = poly.oct_to_poly(d["regions"])
n0 = sorted(cert)[0]
cert[n0] = {k: [0, 1] for k in cert[n0]} | {"1,1": [0, 1], "1,-1": [-1, 0]}
ok("3D referee rejects a broken drawing", not check(codes[d["id"]]["codewords"], cert, poly.DIRS4)[0])

# 3. T3 is a real member of the family: no local obstruction
ok("T3 has no local obstruction", not has_local_obstruction(set(T3) | {frozenset()}))

# 5. T3 IS drawable in 3D: the search must find it, and the referee must accept it
r, cert, rounds = sat_search(T3, DIAG3, 4, 600)
ok(f"T3 found in 3D ({r}, {rounds} rounds)", r == "SOLVED" and check(T3, cert, DIAG3)[0])
print("T3 drawing:", json.dumps(cert))

# 4. T3 is NOT drawable in the plane: on 0..3 with 8 directions the decider must say NO
#    (on 0..4 it ran 16+ minutes; the general fact is Jeffs' theorem, this is a solver sanity check)
r, _, pv = poly.decide(T3, 3, poly.DIRS8, "/tmp/t3_2d", proof=False, timeout_s=1800)
ok(f"T3: no 8-direction drawing in the plane on 0..3 (got {r})", r == "UNSAT")

# 6. boxes in 3D (axes only) can't draw the triangle-hole code {12,13,23,1,2,3} with no 123?
#    (the hollow triangle is convex, but not with boxes: Helly) -> search says NONE_ON_GRID
r, _, _ = search(parse_short("12 13 23 1 2 3".split()), AX3, 3, 120)
ok(f"hollow triangle: no 3D box drawing (got {r})", r == "NONE_ON_GRID")
print("\nAll poly3d tests passed.")
