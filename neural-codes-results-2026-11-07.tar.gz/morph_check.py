"""
morph_check.py - looks for a NON-CONVEXITY certificate using morphisms (Jeffs,
"Morphisms of Neural Codes", arXiv:1806.02014).

The math:
 - Trunk of sigma: Tk(sigma) = all codewords that contain sigma.
 - Pick any list of trunks T1..Tm. Send each codeword c to {j : c is in Tj}.
   The set of results is an "image" of the code (every morphism image looks like
   this, Prop. 2.12).
 - Thm 1.3: the image of a convex code is convex.
 - Known fact: a code with a local obstruction is not convex.
 So: if SOME image has a local obstruction, the original code is NOT convex.

Certificate = the trunk faces used, the image, a face sigma of the image's complex
that is missing from the image, and the link's nonzero GF(2) Betti numbers (proof
the link is not contractible). verify_cert rebuilds everything from scratch.

Run: python3 morph_check.py jeffs_96_codes.json MAX_NEURONS [ids...]
"""
import json, os, sys, time
from itertools import combinations
from neuralcodes import (make_code, facets, facet_intersections, link_facets,
                         reduced_betti_gf2, in_complex)


def trunk(code, sigma):
    sigma = frozenset(sigma)
    return frozenset(c for c in code if sigma <= c)


def all_trunks(code):
    """Distinct nonempty trunks, each with one face that defines it. Skips the
    whole code (Tk of the empty face), which only adds a neuron that always fires."""
    out = {}
    faces = {frozenset(s) for c in code for k in range(1, len(c) + 1)
             for s in combinations(sorted(c), k)}
    for s in sorted(faces, key=lambda f: (len(f), sorted(f))):
        T = trunk(code, s)
        if T and T != frozenset(code) and T not in out:
            out[T] = s
    return out                      # {trunk: defining face}


def image(code, trunk_list):
    return {frozenset(j + 1 for j, T in enumerate(trunk_list) if c in T) for c in code}


def obstruction(img):
    """A face sigma of Delta(img), missing from img, whose link has nonzero GF(2)
    homology (so it is provably not contractible). None if there is no such face.
    Homology only: images can have many neurons, and exhaustive collapsing blows up.
    Only intersections of facets need testing (other faces have cone links)."""
    F = facets(img)
    cands = [s for s in facet_intersections(F) if s not in img and s not in F]
    for s in sorted(cands, key=lambda f: (len(f), sorted(f))):
        if any(b != 0 for b in reduced_betti_gf2(link_facets(s, F))):
            return s
    return None


def find_bad_image(code, max_neurons=5):
    code = {frozenset(c) for c in code}
    tr = all_trunks(code)
    T = list(tr)
    seen = set()
    for m in range(1, min(max_neurons, len(T)) + 1):
        for pick in combinations(range(len(T)), m):
            img = frozenset(image(code, [T[i] for i in pick]))
            h = hash(img)
            if h in seen:                      # skip repeats (hash only, to save memory;
                continue                       # a rare collision just skips one image)
            seen.add(h)
            sigma = obstruction(set(img))
            if sigma is not None:
                L = link_facets(sigma, facets(set(img)))
                return {"trunk_faces": [sorted(tr[T[i]]) for i in pick],
                        "image": sorted(sorted(c) for c in img),
                        "obstruction_face": sorted(sigma),
                        "link_facets": sorted(sorted(f) for f in L),
                        "link_betti_gf2": reduced_betti_gf2(L)}
    return None


def verify_cert(code, cert):
    """Rebuild the image from the trunk faces and re-prove the obstruction."""
    code = {frozenset(c) for c in code}
    img = image(code, [trunk(code, s) for s in cert["trunk_faces"]])
    if sorted(sorted(c) for c in img) != cert["image"]:
        return False
    sigma = frozenset(cert["obstruction_face"])
    F = facets(img)
    if not sigma or sigma in img or not in_complex(sigma, F):
        return False
    L = link_facets(sigma, F)
    if L == {frozenset()}:
        return False                           # sigma is a facet, so it is in img; never here
    return any(b != 0 for b in reduced_betti_gf2(L))


def main():
    path, mx = sys.argv[1], int(sys.argv[2])
    only = set(sys.argv[3:])
    codes = json.load(open(path))["codes"]
    os.makedirs("noncvx_certificates", exist_ok=True)
    for c in codes:
        cid = c["id"]
        if only and cid not in only:
            continue
        code = make_code(c["codewords"])
        t0 = time.time()
        cert = find_bad_image(code, mx)
        if cert:
            assert verify_cert(code, cert), f"{cid}: certificate failed its own check"
            json.dump({"id": cid, "source_id": c["source_id"], "status": "NONCONVEX",
                       "reason": "an image under a morphism has a local obstruction", **cert},
                      open(f"noncvx_certificates/{cid}.json", "w"), indent=1)
        print(cid, "NONCONVEX" if cert else "no bad image", f"({time.time()-t0:.1f}s)", flush=True)


if __name__ == "__main__":
    main()
