"""planar_triangle.py - search for the "triangle + sunflower" argument that a code has NO convex
open drawing in the PLANE (it says nothing about 3D). Pattern, generalizing the C5-068 hand proof:

  petals P1, P2, P3 (faces): every codeword containing Pi|Pj contains P1|P2|P3, and some codeword
     does (sunflower with nonempty center; in R^2 three petals are enough: Jeffs Thm 5.2 puts a
     center point o inside any triangle with one corner in each petal).
  corners a, b, c in codewords A > P1, B > P2, C > P3.
  each side, e.g. ab (inside U_{A&B}): sets I < A, J < B with every codeword containing A&B
     containing I or J. Then side ab has a point x whose codeword contains X_ab = I | J | (A&B).
  cut the triangle into a-x-y, b-x-z, c-y-z, x-y-z. They lie in U_K for
     K = A&X_ab&X_ac,  B&X_ab&X_bc,  C&X_ac&X_bc,  X_ab&X_ac&X_bc.
  If every K is nonempty and no codeword contains K | P1|P2|P3, the center point o has nowhere to
  be: NOT PLANAR. Every step is a lookup in the code, so a hit is a full proof (given Thm 5.2).
Usage: python3 proofs/planar_triangle.py [ids...]   (no ids = all 96)
"""
import json, sys
import os; ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
from itertools import combinations, permutations

codes = {c["id"]: c for c in json.load(open(os.path.join(ROOT, "jeffs_96_codes.json")))["codes"]}
s = lambda w: "".join(map(str, sorted(w))) or "{}"


def subsets(X):
    X = sorted(X)
    return [frozenset(c) for k in range(len(X) + 1) for c in combinations(X, k)]


def find(codewords):
    words = [frozenset(w) for w in codewords] + [frozenset()]
    words = list(set(words))
    nz = [w for w in words if w]
    cont = lambda X: [w for w in words if X <= w]
    faces = list({f for w in nz for f in subsets(w) if f})

    def side_points(A, B):
        """all X that some point of segment ab is guaranteed to contain"""
        base = A & B
        out = set()
        on = cont(base)
        for I in subsets(A):
            for J in subsets(B):
                if all(I <= w or J <= w for w in on):
                    out.add(I | J | base)
        # keep only the largest ones (a bigger X is a stronger fact)
        return [x for x in out if not any(x < y for y in out)]

    cache = {}
    for P1, P2, P3 in combinations(faces, 3):
        Z = P1 | P2 | P3
        top = cont(Z)
        if not top or any(set(map(frozenset, cont(p | q))) != set(map(frozenset, top))
                          for p, q in ((P1, P2), (P1, P3), (P2, P3))):
            continue
        for A in [w for w in nz if P1 <= w]:
            for B in [w for w in nz if P2 <= w]:
                for C in [w for w in nz if P3 <= w]:
                    sp = {}
                    for (u, v) in ((A, B), (A, C), (B, C)):
                        if (u, v) not in cache:
                            cache[u, v] = side_points(u, v)
                        sp[u, v] = cache[u, v]
                    for Xab in sp[A, B]:
                        for Xac in sp[A, C]:
                            for Xbc in sp[B, C]:
                                Ks = [A & Xab & Xac, B & Xab & Xbc, C & Xac & Xbc, Xab & Xac & Xbc]
                                if all(K and not cont(K | Z) for K in Ks):
                                    return dict(petals=[s(P1), s(P2), s(P3)], center=s(Z),
                                                corners=[s(A), s(B), s(C)],
                                                side_points=[s(Xab), s(Xac), s(Xbc)],
                                                pieces=[s(K) for K in Ks])
    return None


if __name__ == "__main__":
    ids = sys.argv[1:] or sorted(codes)
    for cid in ids:
        print(cid, find(codes[cid]["codewords"]), flush=True)
