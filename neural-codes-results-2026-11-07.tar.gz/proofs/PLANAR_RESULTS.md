# 23 open codes have NO convex open drawing in the plane (proved)

Tool: Jeffs, "Sunflowers of convex open sets" (arXiv:1810.03741), Corollary 2.1 (checked verbatim
in the PDF): "Let {U1,...,Un} be a sunflower of convex open sets with center U in R^d where
n >= d+1, and let p_i in U_i. Then conv{p1,...,pn} intersects U." Sunflower = pairwise
intersections nonempty and all equal. In the plane (d = 2), three petals are enough.

The argument (proofs/planar_triangle.py finds it; every step is a lookup in the code):
1. Three petals P1, P2, P3 whose pairwise overlaps are exactly the center Z (code-level check:
   the codewords containing Pi|Pj are exactly the codewords containing Z, and there is one).
2. Corners a, b, c in codewords containing P1, P2, P3. The triangle abc contains a center point o.
3. Each side of the triangle passes through a known region (connected segment, two open sets
   covering it). Cut the triangle into 4 smaller triangles; each lies inside one U_K.
4. No codeword contains K together with Z, for all four pieces. So o has nowhere to be.

Simplest case (C5-001, Appendix A.1 code (1) of the Wheels paper):
code {1,2,3,12,13,45,46,145,456,2346}. U2, U3, U4 overlap pairwise only inside 2346 (sunflower).
U1 meets all three petals (codewords 12, 13, 145) but never meets U234 (no codeword has 1234).
Pick p2 in U12, p3 in U13, p4 in U145: the triangle is inside U1 (convex), but must contain a
point of U234. Contradiction. So C5-001 cannot be drawn in the plane.

Codes proven not planar (23):
C5-001 007 012 017 018 036 037 038 042 044 047 050 054 056 059 060 062 068 069 086 088 090 094
(full certificates: proofs/planar_triangle_all.txt; C5-068 written out by hand in C5-068_not_planar.md)

Controls:
- All 63 codes I have drawn in the plane: none flagged (if the logic were wrong, these would catch it).
- Known non-convex C0: flagged (correct, it has no drawing anywhere).
- T3 (convex in 3D, not in 2D): not flagged. Its non-planarity uses a different argument, so the
  check is not complete; codes it misses may still be non-planar.

What it means: these 23 are either NON-convex, or convex only in 3D or higher, like T3.
It does NOT prove non-convexity. Next: 3D search on these 23.
Not planar-flagged open codes (10): C5-011 013 033 053 067 072 076 085 087 095
