"""planar_graph.py - second "can't be flat" test: a forced crossing.

Put one point in each codeword's region. Join two points by a straight segment when their codewords
share a neuron set S = A&B (nonempty): the whole segment lies in U_S. Two segments with no common
endpoint can only cross at a point of U_{S1|S2}; if no codeword contains S1|S2 they can NEVER cross
(a segment passing through another point counts as touching, and is ruled out the same way).
If some 6 points with 9 such segments form K3,3 (or 5 points form K5) and every pair of
non-adjacent segments can never cross, the straight-line drawing would be a planar drawing of
K3,3 / K5 (Hanani-Tutte: independent edges never crossing => planar). Impossible. So: NOT PLANAR.
Usage: python3 proofs/planar_graph.py [ids...]
"""
import json, sys
import os; ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
from itertools import combinations

codes = {c["id"]: c for c in json.load(open(os.path.join(ROOT, "jeffs_96_codes.json")))["codes"]}
s = lambda w: "".join(map(str, sorted(w)))


def find(codewords):
    words = sorted({frozenset(w) for w in codewords if w}, key=lambda w: (len(w), sorted(w)))
    allw = words
    has = lambda X: any(X <= w for w in allw)

    def ok_edge(a, b):
        return bool(a & b)

    def never_cross(e, f):
        return not has((e[0] & e[1]) | (f[0] & f[1]))

    def good(edges):
        if not all(ok_edge(*e) for e in edges):
            return False
        for e, f in combinations(edges, 2):
            if set(e) & set(f):
                continue
            if not never_cross(e, f):
                return False
        return True

    for six in combinations(words, 6):
        for left in combinations(six, 3):
            if six[0] not in left:
                continue
            right = [w for w in six if w not in left]
            edges = [(a, b) for a in left for b in right]
            if good(edges):
                return "K33", [s(w) for w in left], [s(w) for w in right]
    for five in combinations(words, 5):
        edges = list(combinations(five, 2))
        if good(edges):
            return "K5", [s(w) for w in five]
    return None


if __name__ == "__main__":
    for cid in sys.argv[1:] or sorted(codes):
        print(cid, find(codes[cid]["codewords"]), flush=True)
