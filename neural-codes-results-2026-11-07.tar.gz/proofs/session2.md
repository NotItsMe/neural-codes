# Session 2 (group 2): LSW segment argument on C5-001, C5-017, C5-038, C5-048, C5-059, C5-003, C5-072, C5-088

## Verdict summary

| Code | Verdict |
|---|---|
| C5-001 | NO SETUP WORKS (template) |
| C5-017 | NO SETUP WORKS (template) |
| C5-038 | NO SETUP WORKS (template) |
| C5-048 | NO SETUP WORKS (template) |
| C5-059 | NO SETUP WORKS (template) |
| C5-003 | NO SETUP WORKS (template) |
| C5-072 | NO SETUP WORKS (template) |
| C5-088 | NO SETUP WORKS (template) |

"(template)" means: no setup of the segment form below satisfies every condition. It does not show that the code is convex. A different argument (for example one using three or more neurons to cover the segment) could still work, and I did not rule that out.

## The argument I checked (reduction)

Setup: a wall neuron k, three faces t1, t2, t3 with W_i = U_{t_i}, triple T = t1 u t2 u t3, and a middle face t_m (say W2 = U_{t_m}) with two ends W1, W3. Let L be the line through p and q below.

Conditions:
- (C1) Triple nonempty: some codeword contains T.
- (C2) Pairwise equal: for each pair, the codewords containing t_i u t_j equal the codewords containing T. Then W_i cap W_j = T as sets.
- (C3) Wall: no codeword contains k together with T. So U_k cap T = empty.
- (C4) Middle inside a cover: t_m \ {k} is contained in {a, b} for two neurons a, b (neither equal to k). Then U_{kab} is inside W_m.
- (C5) Covering: every codeword containing k contains a or b. Equivalently U_k is inside U_a union U_b.
- (C6) Witnesses: some codeword contains t_1 u {k, a} and some codeword contains t_3 u {k, b} (or the same with a and b swapped). This gives p in W1 cap U_{ka} and q in W3 cap U_{kb}, and both lie in U_k.

Proof given (C1) to (C6):
1. p, q are in U_k, so [p,q] is inside U_k (convex). p is in U_a and q is in U_b.
2. Connectedness: [p,q] is covered by the two relatively open sets [p,q] cap U_a and [p,q] cap U_b, by (C5). Both are nonempty. If they were disjoint, [p,q] would be disconnected. So some r in [p,q] lies in U_{kab}, which is inside W_m by (C4).
3. p is not equal to q: otherwise p is in W1 cap W3 = T and in U_k, against (C3).
4. The line L through p and q meets W1, W_m and W3, so by LSW Lemma 3.2 it meets T at a point x.
5. x is not in [p,q], since [p,q] is inside U_k and T cap U_k is empty. So either p lies between x and r, or q lies between r and x.
   - If q lies between r and x: [r,x] is inside W_m (both endpoints are). So q is in W_m cap W3 = T, but q is in U_k. Contradiction with (C3).
   - If p lies between x and r: the same argument puts p in W_m cap W1 = T. Contradiction.
So (C1) to (C6) make the code non-convex, given the lemma.

Check on the paper's example {2345,123,134,145,13,14,23,34,45,3,4,empty}: the checker flags 4 setups, including W=(U23,U34,U45), k=1, a=3, b=4, which is the paper's argument. So the conditions are consistent with the known proof.

The checker (exhaustive over all face triples, walls, middle choices, two-neuron covers and witness assignments) was a one-off script and is not included. The lsw_template.py output is weaker: it does not check (C4), (C5) or (C6), so its hits (like W=U2,U3,U4 for C5-001) are not usable on their own.

Result: for all eight codes, no setup satisfies (C1) to (C6). In every near-miss the failing condition is (C5), the covering. A codeword containing k but avoiding both a and b lets a segment inside U_k pass through a region that does not meet U_mid, so r is not forced.

## C5-001

Code: empty 1 2 3 12 13 45 46 145 456 2346. Maximal: 12 13 145 2346 456. Triple candidate: 2346 (only codeword containing 2346). Wall candidate: k=1.

- Setups that pass (C1) to (C4) and (C6) with non-degenerate middle: none. The only near-misses have middle W_m = T (degenerate: then r would lie in T cap U_k, which is empty).
- The lsw_template setup (W = U2, U3, U4, wall 1) fails at (C5): the codeword "1" contains the wall neuron 1 and avoids any a,b other than 1 itself, so no two-neuron cover works.
- Why the segment can't be forced here: the codeword "1" is a codeword. Inside U1, a path from U12 to U145 can pass through the points with codeword exactly "1", which lie in neither U3 nor U4. Nothing forces the segment through U3.

Verdict: NO SETUP WORKS (template). No non-degenerate setup of this form exists for this code.

## C5-017

Code: empty 1 2 12 34 35 56 134 156 345 2356. Maximal: 12 134 156 2356 345. Triple T = 134 (cont = {134}).

Best near-miss (fails only at C5): W1 = U1, W2 = U13 (middle), W3 = U34, k = 5, a = 1, b = 3.
- (C1), (C2), (C3), (C4), (C6) hold: codeword 156 gives the witness for U1 cap U15, codeword 345 gives the witness for U34 cap U35.
- (C5) fails: codeword 56 contains 5 and avoids 1 and 3.

Verdict: NO SETUP WORKS (template). Gap: a segment inside U5 from U1 to U34 can run through the region of codeword 56 without meeting U13.

## C5-038

Code: empty 4 6 12 13 35 123 124 126 135 3456. Maximal: 123 124 126 135 3456. Triple T = 135 (cont = {135}).

Best near-miss: W1 = U1, W2 = U15 (middle), W3 = U35, k = 4, a = 1, b = 5.
- (C1) to (C4), (C6) hold: codeword 135 gives both witnesses.
- (C5) fails: codeword 4 contains 4 and avoids 1 and 5.

Verdict: NO SETUP WORKS (template). Gap: a segment inside U4 can run through the point with codeword "4" (a codeword of this code) without meeting U15.

## C5-048

Code: empty 1 5 12 13 14 16 23 123 124 156 235 1346. Maximal: 123 124 1346 156 235. Triple T = 123 (cont = {123}).

Best near-miss: W1 = U12, W2 = U23 (middle), W3 = U13, k = 4, a = 2, b = 3.
- (C1) to (C4), (C6) hold.
- (C5) fails: codeword 14 contains 4 and avoids 2 and 3.

Verdict: NO SETUP WORKS (template). Gap: a segment inside U4 can run through the region of codeword 14 without meeting U23.

## C5-059

Code: empty 1 2 12 23 24 56 123 124 156 345 2345 3456. Maximal: 123 124 156 2345 3456. Triple T = 123 (cont = {123}).

Best near-miss: W1 = U1, W2 = U13 (middle), W3 = U23, k = 4, a = 1, b = 3.
- (C1) to (C4), (C6) hold.
- (C5) fails: codeword 24 contains 4 and avoids 1 and 3.

Verdict: NO SETUP WORKS (template). Gap: a segment inside U4 can pass through the region of codeword 24 without meeting U13.

## C5-003

Code: empty 1 2 3 12 13 45 46 245 346 1456. Maximal: 12 13 1456 245 346. Triple T = 145 (cont = {1456}).

Best near-miss: W1 = U1, W2 = U14 (middle), W3 = U45, k = 2, a = 1, b = 4.
- (C1) to (C4), (C6) hold.
- (C5) fails: codeword 2 is a codeword of this code; it contains 2 and avoids 1 and 4.

Verdict: NO SETUP WORKS (template). Gap: a segment inside U2 can pass through the point with codeword "2" without meeting U14.

## C5-072

Code: empty 3 4 13 15 23 26 123 145 246 356 1356 2356. Maximal: 123 1356 145 2356 246. Triple T = 123 (cont = {123}).

Best near-miss with fewest violations: W1 = U1, W2 = U16 (middle), W3 = U35, k = 2, a = 1, b = 6, T = 1356.
- (C1) to (C4), (C6) hold.
- (C5) fails: codeword 23 contains 2 and avoids 1 and 6.

Other near-miss: W1 = U1, W2 = U12, W3 = U23, k = 5, a = 1, b = 2, T = 123, violator 356.

Verdict: NO SETUP WORKS (template). Gap: a segment inside U2 can pass through the region of codeword 23 without meeting U16.

## C5-088

Code: empty 1 2 3 4 12 13 23 34 123 124 146 245 1245 1246 1346 2345. Maximal: 123 1245 1246 1346 2345. Triple T = 123.

Best near-miss: W1 = U12, W2 = U13 (middle), W3 = U23, k = 5, a = 1, b = 3.
- (C1) to (C4), (C6) hold.
- (C5) fails: codeword 245 contains 5 and avoids 1 and 3.

Verdict: NO SETUP WORKS (template). Gap: a segment inside U5 can pass through the point with codeword 245 without meeting U13.

## Notes for later

- The reduction (C1) to (C6) is the reusable part. The outer-piece step (points beyond p or q) is automatic once the segment lies in U_k and W_m is convex, so the only thing a setup must supply is the covering that forces r into the middle set. Any code that gets a PROOF from this template is non-convex, given the lemma.
- lsw_template.py output (setups with a wall neuron) is not enough: it omits the covering and middle-containment conditions. Use the stricter checker instead.
- Possible next steps for a later session: try covers by three or more neurons (U_a, U_b, U_c) for the segment, which the template does not allow.
