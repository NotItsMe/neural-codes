# Session 4: LSW-style non-convexity attempts (group 4)

Codes: C5-011, C5-033, C5-044, C5-053, C5-006, C5-062, C5-085, C5-094.
Work used only the code data and the tools code_facts.py and lsw_template.py. No certificates, poly_results, sat_results or log files were read.

**Verdicts (summary)**

- C5-011: NO SETUP WORKS
- C5-033: NO SETUP WORKS
- C5-044: NO SETUP WORKS
- C5-053: NO SETUP WORKS
- C5-006: NO SETUP WORKS
- C5-062: NO SETUP WORKS
- C5-085: NO SETUP WORKS
- C5-094: NO SETUP WORKS

None of these is a claim about convexity. "NO SETUP WORKS" means the LSW segment argument cannot be completed from the codeword facts in any setup that lsw_template.py lists. The codes stay UNKNOWN.

---

## Reusable tools (derived here, used for every code)

Notation: for a set X, U_X is the intersection of U_i over i in X. A point z in U_X has codeword containing X. "Wall" region: U_X for X = {k}.

**Switch lemma (proved from the facts in the plan).** Let a, b not in X, a != b. Let p in U_{X+a} and q in U_{X+b}. Then [p,q] lies in U_X. Suppose no codeword containing X avoids both a and b. Then [p,q] meets U_{X+a+b}.

Proof. A = [p,q] cap U_{X+a} and B = [p,q] cap U_{X+b} are relatively open in the segment and nonempty (p in A, q in B). Every point z of the segment lies in U_X, so its codeword contains X. If z were in neither U_a nor U_b, its codeword would be a codeword containing X and avoiding a, b, which the hypothesis excludes. So A cup B is the whole segment. The segment is connected, so A and B meet. A point in A cap B lies in U_{X+a} cap U_{X+b} = U_{X+a+b}. Q.E.D.

Two consequences used below:

- (N-switch) If X is itself a codeword, then that codeword contains X and avoids every a, b outside X, so the lemma never applies. The plan's example works because "1 alone" is not a codeword.
- (N-wall) The LSW final step needs the triple T = U_{union of the W index sets} to be unreachable from the segment, i.e. no codeword contains X together with the triple's index set. If it is reachable, the line's point in the triple can sit on the segment itself, and there is no contradiction.

So a setup can carry the argument only if some region U_X (i) meets all three W's, (ii) has no codeword containing X plus the triple, and (iii) admits a pair a, b with the switch lemma applying and the middle witness W2 contained in U_{X+a+b}.

I ran this check over every setup that lsw_template.py lists for each code. The two helper scripts were one-offs and are not included. The filter results are stated per code below.

---

## C5-011

Code: empty 1 2 5 6 12 13 34 134 135 256 346. Maximal: 12 134 135 256 346.

Setups (template): W = U2, U5, U6 with triple 256 (wall 1 and wall 3). Two setups listed.

Check:
- Wall 1: U1 meets U2 (codeword 12) and U5 (codeword 135), but not U6 (no codeword contains 16). So the segment inside U1 cannot be forced to meet U6.
- Wall 3: U3 meets U5 (135) and U6 (346), but not U2 (no codeword contains 23).
- The region test (script run over both setups) finds no region U_X that meets all three W's and keeps the triple unreachable, so (i) and (ii) cannot both hold.

GAP: none, because the step fails outright. The segment cannot carry the witness for the third W.

**Verdict: NO SETUP WORKS.** Every setup has a region that misses one of the three W's, or whose triple is reachable.

---

## C5-033

Code: empty 1 2 3 12 36 134 235 345 1345 1346 2345 2356. Maximal: 12 1345 1346 2345 2356.

Setups: lsw_template.py lists zero choices of W1, W2, W3 (as U_t sets) satisfying Lemma 3.2's hypotheses (nonempty triple, all pairwise intersections equal the triple).

So the lemma cannot be invoked with W's of this form. Taking the template's enumeration as the scope of the attempt, there is no LSW setup.

**Verdict: NO SETUP WORKS.** No triple satisfies Lemma 3.2's hypotheses.

---

## C5-044

Code: empty 2 6 12 13 15 23 24 123 124 135 156 2346. Maximal: 123 124 135 156 2346.

Setups (template): 7. Triple 2346 for W = U3, U4, U6 and related choices.

Check of the setups that pass the region test (wall region U1 meets all three W's and the triple is unreachable): W = U3, U4, U6 (walls 1 and 5), W = U3, U6, U24 (walls 1 and 5), W = U4, U6, U23 (wall 1), W = U6, U23, U24 (wall 1). All of these use X = {1}.

For X = {1}, the switch lemma needs a in S1 minus {1}, b in S3 minus {1}, and the middle set S2 contained in {1, a, b}. For each of these setups no such pair (a, b) exists, or the required codeword 1 plus a, b is empty. Example: W = U3, U4, U6 gives a = 3, b = 6, and the switch would force a codeword containing 1, 3, 6 (none exists in the code), but the switch hypothesis fails because codewords 12, 15, 124 contain 1 and avoid both 3 and 6. Those codewords let a segment inside U1 go from the 3-side to the 6-side without touching U4. So the witness in U4 is not forced.

GAP (cannot be closed from the code): the segment [p,q] inside U1 can avoid U4 through the codeword 15 (or 12). Nothing in the codeword facts forbids this.

**Verdict: NO SETUP WORKS.** In every setup where the wall condition holds, the switch witness cannot be forced onto the segment.

---

## C5-053

Code: empty 1 4 12 23 35 56 123 124 156 345 2356. Maximal: 123 124 156 2356 345.

Setups (template): 6, all with triple 2356 (e.g. W = U2, U6, U35; U2, U35, U56; U6, U23, U35; U23, U35, U56).

Check: no region U_X meets all three W's with the triple unreachable. The forced-switch configurations that do exist (for example X = 6 with a = 2, b = 5 for W = U2, U56, U35) all have the codeword 2356 containing X together with the triple, so the segment itself can meet the triple. The lemma's point could lie on the segment, and no contradiction follows.

**Verdict: NO SETUP WORKS.** The forced segment always reaches the triple (N-wall fails).

---

## C5-006

Code: empty 1 2 3 4 12 25 34 56 156 235 2456. Maximal: 12 156 235 2456 34.

Setups (template): 6, all with triple 2456 (e.g. W = U2, U4, U6; U2, U4, U56; U4, U6, U25; U4, U25, U56).

Check: the filter finds no region U_X that meets all three W's with the triple unreachable. Forced switch configurations exist only with X = 6 (for example a = 4, b = 5 for W = U4, U6, U25), and there the codeword 2456 contains 6 together with the triple, so the triple is reachable from the segment (N-wall fails).

**Verdict: NO SETUP WORKS.**

---

## C5-062

Code: empty 1 2 3 4 12 13 14 23 24 123 124 345 346 1345 2346 3456. Maximal: 123 124 1345 2346 3456.

Setups (template): 12, of which four are wall-clean: W = U12, U13, U23 (wall 4, triple 123), W = U12, U14, U24 (wall 3, triple 124), W = U13, U14, U34 (wall 2, triple 134), W = U23, U24, U34 (wall 1, triple 234).

Check: every wall-clean setup uses a region X = {k} with k in {1, 2, 3, 4}. Each of these singletons is itself a codeword in C5-062 (codewords "1", "2", "3", "4" all occur). By (N-switch), the codeword {k} contains X and avoids every a, b, so the switch never applies. The segment can run through the point with codeword {k} without meeting the third witness.

Concretely, for X = {4} and W = U12, U13, U23: the codeword "4" avoids 1 and 3, and "24" avoids 1 and 3, so a segment in U4 can go from the 1-side to the 3-side without passing through 1345.

GAP (cannot be closed): the segment can pass through the codeword point for k.

**Verdict: NO SETUP WORKS.**

---

## C5-085

Code: empty 1 4 12 13 46 123 124 145 345 1245 1246 1345 3456. Maximal: 123 1245 1246 1345 3456.

Setups (template): 12, all with triple around 1345 (e.g. W = U13, U14, U34; U13, U15, U34; U13, U34, U145; U13, U145, U345).

Check: no region U_X meets all three W's with the triple unreachable. The forced-switch configurations that exist use X = 3 or X = 5 (for example a = 1, b = 4 with W = U13, U14, U34), and there the triple's codeword 1345 contains X, so the triple is reachable from the segment (N-wall fails).

**Verdict: NO SETUP WORKS.**

---

## C5-094

Code: empty 1 2 5 15 25 34 123 126 134 234 345 1234 1236 1256 1345 2345. Maximal: 1234 1236 1256 1345 2345.

Setups (template): 43 listed. Of these, 25 (setup, region) pairs pass the "all three W's meet the region and the triple is unreachable" test. Examples: W = U6, U15, U25 (region X = 3, walls 3 and 4); W = U12, U13, U23 (X = 5); W = U12, U15, U25 (X = 3 or 4); W = U13, U15, U35 (X = 2).

Check of switch condition on those 25 pairs (script output shows zero bridgeless pairs):
- Where X is a singleton codeword (X = 2 or X = 5, both codewords here), (N-switch) blocks the lemma.
- Where X = 3 or X = 4 (not codewords), the switch needs a middle set S2 contained in {X, a, b}. For W = U6, U15, U25 no such pair exists. For W = U12, U15, U25 every candidate (a, b) is bridged by a codeword: 34 or 234 (avoiding 1 and 5) for X = 3, and 34, 134 or 345 for the other pairs, depending on which a, b are chosen. So the segment can avoid the forced witness.

GAP (cannot be closed): the bridging codewords 34, 234, 134, 345 are real codewords of the code, so a segment in U3 or U4 can avoid the needed codeword point.

**Verdict: NO SETUP WORKS.** This is the strongest of the eight in terms of candidates (25 setups pass the region test), but none passes the switch step.

---

## Notes for later

- The plan's example uses X = {1} with "1 alone is not a codeword". The general form of that condition is (N-switch): X must not be a codeword and no codeword containing X may avoid both a and b. Checking this first would have ruled out most of the setups above at once.
- The region test and the switch test are independent. A setup that passes the region test (C5-062, C5-094) still fails the switch step. A setup whose switch works (C5-044 with X = 1 in some configurations, several in C5-094) fails the wall test.
- For future batches: run the (region, wall, switch) check first. Only setups passing all three are worth writing out.

Memory: nothing in the user's memory snapshot bore on this task, so none was used.
