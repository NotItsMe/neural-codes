# Session 1 (group 1): LSW segment proof attempts

## Method used across all codes

I formalized the LSW segment argument as a general criterion and then searched every setup mechanically (all W's of the form U_s, every size, every wall k, every switch pair {a,b}). The search was checked against the known LSW code {2345,123,134,145,13,14,23,34,45,3,4}: it recovers the LSW setup (wall 1, switch 3 and 4, W's containing 34). It finds nothing for any of the eight codes.

**Criterion (sufficient for non-convexity).** Pick a wall k, two switch neurons a and b, and W1=U_s1, W2=U_s2, W3=U_s3 with T = s1 u s2 u s3. Require:
- (W) cw(s1 u s2) = cw(s1 u s3) = cw(s2 u s3) = cw(T) and cw(T) nonempty (here cw(X) = codewords containing X).
- (A) No codeword contains T u {k}.
- (G) Every codeword containing k contains a or b.
- (Y) Every codeword containing {k,a,b} contains s2.
- (P) Some codeword C_p contains s1 u {k}, contains a, and not b. Some codeword C_q contains s3 u {k}, contains b, and not a.

**Why it is a proof.** Take p in the atom of C_p and q in the atom of C_q. By (A), p is not in U_s3 and q is not in U_s1. The segment [p,q] lies in U_k. By (G), [p,q] is covered by the relatively open sets U_a and U_b. Each contains an endpoint that the other does not, so by connectedness they overlap at some y, and y's codeword contains {k,a,b}, so y is in U_s2 by (Y). The line L through p and q meets W1 (at p), W2 (at y) and W3 (at q). By LSW Lemma 3.2, L meets U_T at some x. If x lies on [p,q], then x is in U_T u U_k, contradicting (A). If x lies beyond p, then p lies on [x,q], which is inside U_s3, contradicting p not in U_s3. Beyond q is symmetric. So no convex realization exists.

**Result of the search.** No setup satisfies (W), (A), (G), (Y), (P) for any of the eight codes. The obstruction differs by code (see each section). In the tables below, "gap test" means (G) and (P) hold for some wall k and switch pair {a,b}.

---

## C5-068

Code: 3 5 6 12 14 24 123 124 145 246 356 (plus empty). Maximal words: 123 124 145 246 356.

Setups from lsw_template: W = U3, U5, U6 with wall 1, 2 or 4. The triple part is codeword 356 (cw(35)=cw(36)=cw(56)=cw(356)={356}).

**Hand version of the LSW argument (wall 1, W1=U3, W2=U5, W3=U6, T=U356).**
- Witness p in U123 (in U1 and U3, not U5). Witness q in U145 (in U1 and U5, not U3). The segment [p,q] lies in U1.
- Codewords containing 1 are 12, 14, 123, 124, 145. None contains 356, so U356 is disjoint from U1.
- The only way the segment can get from U3-only to U5-only is through the overlap U_{35} = U356, which lies outside U1. So the gap points of the segment (codewords containing 1 but neither 3 nor 5) must exist, and they are 12, 14 or 124. None of these contains 6. So the segment does not reach U6 at all, and the lemma cannot be applied to the line pq through this segment.
- The 1-D bookkeeping is fine: if the line through p and q meets U6 at all, the lemma puts a point of U356 on the line, and that point is outside [p,q], which gives a contradiction. The only missing piece is that the line through p and q does not need to meet U6 anywhere.

**Criterion search.** Wall 1 passes the gap test with switch pair {2,4} (kab = {124}), wall 2 with {1,4}, and wall 4 with {1,2}, each with kab = {124}. The failure is in the triple condition (W) together with (Y): s2 must sit inside 124 while the pairwise unions still have the same codeword set as T. No choice of W's does this.

GAP (the reason this is not PROOF): nothing in the code forces the line through a U3-only point and a U5-only point to meet U6. U1 does not meet U6 (no codeword contains {1,6}), and U2 does not meet U5 (no codeword contains {2,5}). The wall-2 and wall-4 analogues fail for the same reason.

**Verdict: NO SETUP WORKS** for the LSW segment method. Near miss: the argument closes if the line pq meets U6. That is the missing geometric fact.

---

## C5-013

Code: 1 2 5 12 13 34 46 134 135 456 2346 (plus empty). Maximal words: 12 134 135 2346 456.

Setups from lsw_template: six (W2,W3 options with walls 1, 5). Search: gap test passes for wall 3 with {1,4} (kab = {134}) and wall 4 with {3,6} (kab = {2346}). For wall 3 and wall 4 the triple part and the W's do not satisfy (W) and (Y) simultaneously. For wall 6 the (P) condition fails for every switch pair.

**Verdict: NO SETUP WORKS** (for the LSW method). The obstruction is the triple consistency (W) with the switch codeword, not a missing segment.

---

## C5-002

Code: 1 2 3 12 13 45 46 146 245 3456 (plus empty). Maximal words: 12 13 146 245 3456.

Setups from lsw_template: four, all with wall 1 and W's containing 3 or 46 or 6 or 45. The template's setups have the triple part 3456. The gap test passes for wall 4 with switch pair {5,6} (kab = {3456}), but the W's meeting U4 are U5 and U6 only, and the search finds no triple satisfying (W), (A), (Y) and (P) together.

No switch pair passes the gap test (G) for wall 1, so the LSW pattern cannot be copied onto wall 1.

**Verdict: NO SETUP WORKS** (for the LSW method).

---

## C5-037

Code: 2 5 12 13 24 26 123 124 126 135 2456 (plus empty). Maximal words: 123 124 126 135 2456.

Setups from lsw_template: four, all with W's containing 4, 5, 6, 24, 26, with wall 1 and triple part 2456. The gap test passes for wall 1 with switch pair {2,3} (kab = {123}). But the triple 2456 has no part in U1, so the W's must be built from neurons 4, 5, 6 and cw(s) for s in {4,5,6,24,26} shows cw of each pairwise union is a different codeword set than cw(T). The search finds no triple satisfying (W) together with (Y) for the switch pair {2,3}.

**Verdict: NO SETUP WORKS** (for the LSW method).

---

## C5-047

Code: 1 5 6 12 23 24 123 124 156 235 246 (plus empty). Maximal words: 123 124 156 235 246.

Setups from lsw_template: three, all with W's U1, U5, U6 and triple part 156. Wall 2 (W's 1, 5, 6), wall 3 (W's 1, 5), wall 4 (W's 1, 6).

Gap test: the (G) condition passes for several walls and switch pairs, but (P) fails for each of them. For example, wall 4 with switch pair {2,6} has (G) holding with kab = {246}, yet no codeword contains {1,4} with exactly one of 2 and 6 present in the right way for both witnesses.

**Verdict: NO SETUP WORKS** (for the LSW method). The obstruction is the (P) step.

---

## C5-056

Code: 1 2 12 23 24 35 56 123 124 156 356 2345 (plus empty). Maximal words: 123 124 156 2345 356.

Setups from lsw_template: four, wall 1, triple part 2345. Gap test passes for wall 3 with {2,5} (kab = {2345}) and wall 5 with {3,6} (kab = {356}). For wall 3 (switch pair {2,5}) and wall 5 (switch pair {3,6}) the search finds no triple satisfying (W), (A), (Y) and (P) together.

**Verdict: NO SETUP WORKS** (for the LSW method).

---

## C5-069

Code: 2 3 4 5 6 13 14 123 134 145 246 356 (plus empty). Maximal words: 123 134 145 246 356.

This code has the same codewords around neuron 1 as the LSW code: 13, 14, 123, 134, 145. So the gap test with wall 1 and switch pair {3,4} passes (kab = {134}), exactly as in the LSW proof.

**Why the copy fails.** The LSW triple codeword 2345 is missing from this code. The natural analogue is W1=U23, W2=U34, W3=U45 with triple 2345, but cw(2345) is empty, so the lemma's hypothesis "triple nonempty" fails. Other triples (for example the template's U3, U5, U6 with triple 356 at wall 1) pass (W) but fail (Y): the switch codeword 134 must lie in W2, and W2 must then satisfy s2 subset 134 with the pairwise conditions, which no choice does.

**Verdict: NO SETUP WORKS** (for the LSW method). The copy fails at nonemptiness of the triple, which is the step that LSW uses from the lemma.

---

## C5-087

Code: 3 12 14 123 124 145 146 456 1245 1246 1456 3456 (plus empty). Maximal words: 123 1245 1246 1456 3456.

Setups from lsw_template: eight, all with wall 2 and triple part 1456. Gap test passes for wall 1 with {2,4} (kab = {124, 1245, 1246}), wall 4 with {1,5} or {1,6}, wall 5 with {1,6}, and wall 6 with {1,5}. For each of these the search finds no triple satisfying (W), (A), (Y) and (P) together.

**Verdict: NO SETUP WORKS** (for the LSW method).

---

## Summary

| Code | Verdict | Blocking step (LSW criterion) |
|---|---|---|
| C5-068 | NO SETUP WORKS | Triple consistency with the switch codeword 124; the line through the segment need not meet U6 (near miss, see above) |
| C5-013 | NO SETUP WORKS | Triple consistency (W) with switch codeword 134 or 2346 |
| C5-002 | NO SETUP WORKS | (W)/(Y) on triple 3456 |
| C5-037 | NO SETUP WORKS | (W) on triple 2456 |
| C5-047 | NO SETUP WORKS | (P) witnesses |
| C5-056 | NO SETUP WORKS | (W) on triples 2345 and 356 |
| C5-069 | NO SETUP WORKS | Triple 2345 absent, so the LSW copy fails nonemptiness |
| C5-087 | NO SETUP WORKS | (W)/(Y) on triple 1456 |

No code is classified PROOF or PARTIAL. Convexity of these codes is not decided by this work. The criterion only tests the LSW segment pattern, so a NO SETUP WORKS verdict here means the LSW segment argument cannot be forced, not that the code is convex.

Sanity-check artifacts: the search script was a one-off and is not included in proofs/.
