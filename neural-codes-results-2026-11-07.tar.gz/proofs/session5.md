# Session 5 (group 5): LSW segment argument on open neural codes

Codes, in order: C5-009, C5-012, C5-036, C5-045, C5-054, C5-067, C5-086, C5-095.

## Method

For each code I used `code_facts.py` and `lsw_template.py` (the template output is quoted per code below), then ran an exhaustive search for the full segment argument (a one-off script, not included). The search tests every triple of faces (t1, t2, t3) that meets the lemma's hypotheses (T = t1|t2|t3 nonempty, all pairwise intersections equal to the triple part, no W equal to the triple part). For each choice of which W is the crossed one (t_c), and the two endpoint W's (t_i, t_j), it then searches for:

1. a segment region m (any face) with no codeword containing m|T, so U_m and U_T are disjoint, and the segment [p,q] inside U_m avoids U_T;
2. two incomparable faces a, b such that every codeword containing m contains a or b. This covers U_m by U_a and U_b, so by connectedness any segment in U_m from U_a\U_b to U_b\U_a meets U_a&U_b;
3. t_c contained in a|b, so the crossing point lies in W_c = U_{t_c} (needed for the lemma's third set);
4. endpoint codewords: a codeword containing m|t_i|a but not b (a point p in W_i, in U_a, not in U_b), and a codeword containing m|t_j|b but not a (point q in W_j, in U_b, not in U_a).

Validation: the same search run on the LSW Theorem 3.1 code {2345,123,134,145,13,14,23,34,45,3,4,empty} returns the LSW setup (ends U2 and U5, crossed U34, segment in U1, a=U3, b=U4). So the search recovers the known argument.

Result: for all eight codes the search finds zero setups that satisfy 1 to 4 together, so the segment cannot be forced in any setup of this form. This is a statement about this argument only. It does not show the codes are non-convex, and it does not show they are convex. Limits: I did not search triangle versions or covers by three or more sets, and I did not check the outer-piece step (points of the line beyond the segment), because no setup gets that far.

## C5-009

Code: empty 1 2 12 13 14 15 46 134 135 246 1456. Maximal: 12 134 135 1456 246.
Template: 4 setups, all with triple part 1456 and wall neuron 3 (e.g. W=U5,U6,U14; W=U6,U14,U15).
Obstruction for the wall-3 region: codewords containing 3 are 13, 134, 135. All three contain 1 and 3. A cover by two faces must have a face inside {1,3} (the codeword 13 has only neurons 1 and 3), and such a face lies in all three codewords. So the second endpoint codeword (containing the region and the other face but not the first) does not exist.
Exhaustive search: 0 setups.
Verdict: NO SETUP WORKS.

## C5-012

Code: empty 1 2 5 12 13 34 46 134 135 346 2456. Maximal: 12 134 135 2456 346.
Template: 6 setups, triple part 2456, walls 1 and 3 (e.g. W=U2,U4,U5 wall 1; W=U2,U5,U6 wall 3).
Wall 1: codewords containing 1 are 1, 12, 13, 134, 135. The codeword 1 itself forces one cover face to be {1}, which lies in every codeword containing 1, so no second endpoint.
Wall 3: codewords containing 3 are 13, 34, 134, 135, 346. The cover U1 and U4 works (13, 134, 135 contain 1; 34, 134, 346 contain 4). It crosses U14, whose only codeword is 134, and no W of these setups lies inside U14 (I need t_c subset of {1,4}). Also the endpoint in U2 not in U4 inside U1 would need a codeword containing 1, 2 and 3, and there is none.
Exhaustive search: 0 setups.
Verdict: NO SETUP WORKS.

## C5-036

Code: empty 4 5 6 12 13 123 124 126 135 456. Maximal: 123 124 126 135 456.
Template: 2 setups, W=U4,U5,U6, triple part 456, walls 1 and 2.
Wall 1: codewords containing 1 are 12, 13, 123, 124, 126, 135. Every two-face cover of these has one face inside {1,2} and one inside {1,3} (12 forces that the faces come from {1,2}, 13 from {1,3}). The crossing set then lies in U_{a|b} with a|b inside {1,2,3}, and none of 4, 5, 6 is inside {1,2,3}. So the crossed W cannot be contained in the crossing set, which is needed for the lemma's third set. The only two-face cover also has ends in codewords containing 1 with 2 or 3, and the choice a=2, b=3 gives the crossing U23, whose only codeword is 123.
Wall 2: codewords containing 2 are 12, 123, 124, 126. Their common neurons are {1,2}, so a face inside {1,2} lies in all four, and the second endpoint does not exist.
Exhaustive search: 0 setups.
Verdict: NO SETUP WORKS.

## C5-045

Code: empty 12 13 15 24 56 123 124 135 156 2456. Maximal: 123 124 135 156 2456.
Template: 0 candidate setups (with a wall neuron). No triple of faces meets the lemma's pairwise-equal condition together with a wall neuron.
Exhaustive search: 0 setups.
Verdict: NO SETUP WORKS.

## C5-054

Code: empty 1 2 12 13 14 15 56 123 124 156 256 1345. Maximal: 123 124 1345 156 256.
Template: 8 setups, triple part 1345, wall neuron 2 in every case.
The codeword 2 itself contains the wall region {2}. A cover face inside {2} must be {2}, and {2} lies in every codeword containing 2 (2, 12, 123, 124, 256). So no endpoint codeword can lie in the region and outside the first cover face. Every wall-2 region fails this way.
Exhaustive search: 0 setups.
Verdict: NO SETUP WORKS.

## C5-067

Code: empty 1 6 12 13 14 15 24 123 124 145 246 1356. Maximal: 123 124 1356 145 246.
Template: 8 setups, triple parts 356 and 1356, wall neuron 2 (W's meeting U2 are 3, 6 or 6, 13, or 6, 15 etc.) and wall neuron 4.
Wall 2: codewords containing 2 are 12, 24, 123, 124, 246. The cover U1 and U4 works. It crosses U14, whose codewords are 14, 124, 145, and none of the W's in these setups (3, 5, 6, 13, 15) is inside {1,4}.
Wall 4: codewords containing 4 are 14, 24, 124, 145, 246. The cover U1 and U2 works. It crosses U12, and again no W of these setups is inside {1,2}.
Exhaustive search: 0 setups.
Verdict: NO SETUP WORKS.

## C5-086

Code: empty 2 5 6 12 14 23 25 26 56 123 124 145 146 1245 1246 1456 2356. Maximal: 123 1245 1246 1456 2356.
Template: 55 candidate setups (the largest list). Examples: W=U3,U5,U26 wall 1; W=U12,U15,U25 wall 3; W=U12,U16,U26 wall 5.
Wall 1 (region in U1): codewords containing 1 are 12, 14, 123, 124, 145, 146, 1245, 1246, 1456. The cover U2 and U4 works, and it crosses U24 (codewords 124, 1245, 1246). The W's in these setups (3, 5, 26, 56, 23, 25, ...) are not inside {2,4}, so the lemma's third set cannot contain the crossing point. Other covers (U2 with U14, or U12 with U14) cross {1,2,4} or similar sets, and no W fits there.
Exhaustive search: 0 setups.
Verdict: NO SETUP WORKS.

## C5-095

Code: empty 1 15 23 123 126 134 234 236 1234 1236 1256 1345 2346. Maximal: 1234 1236 1256 1345 2346.
Template: 25 candidate setups, walls 3, 4, 5, 6 (e.g. W=U12,U13,U23 wall 5 with triple part 123).
Wall 5: codewords containing 5 are 15, 1256, 1345. All three contain 1, so a face inside {1} covers all of them and the second endpoint does not exist. Walls 4 and 6 have similar cover problems, and the cover-and-crossing step fails the same way (the crossing sets such as {1,3}, {1,2} or {2,3} contain none of the crossed W's in these setups).
Exhaustive search: 0 setups (176 candidate pairs were rejected by the crossing condition or the endpoint condition in the loosened search, and none passes all conditions).
Verdict: NO SETUP WORKS.

## Summary

| Code | Template setups | Exhaustive segment search | Verdict |
|---|---|---|---|
| C5-009 | 4 | 0 | NO SETUP WORKS |
| C5-012 | 6 | 0 | NO SETUP WORKS |
| C5-036 | 2 | 0 | NO SETUP WORKS |
| C5-045 | 0 | 0 | NO SETUP WORKS |
| C5-054 | 8 | 0 | NO SETUP WORKS |
| C5-067 | 8 | 0 | NO SETUP WORKS |
| C5-086 | 55 | 0 | NO SETUP WORKS |
| C5-095 | 25 | 0 | NO SETUP WORKS |

No code is marked PROOF or PARTIAL, because no setup gets past the segment-forcing step.
