# Session 3 (group 3): LSW segment argument on open neural codes

Codes: C5-007, C5-005, C5-018, C5-042, C5-050, C5-060, C5-076, C5-090
Result: all eight are NO SETUP WORKS for the LSW segment argument (family described below). No code is claimed non-convex here.

## 1. The argument in general form (checked, fills a gap in the plan)

Notation: W1 = U_S1, W2 = U_S2, W3 = U_S3 with W1&W2 = W1&W3 = W2&W3 = T = U_(S1 u S2 u S3), T nonempty. Wall k: k is not in the triple and no codeword contains k together with the triple (so T & U_k is empty).

Transit data: disjoint nonempty neuron sets X, Y, with S2 contained in X u Y (so U_X & U_Y is inside W2), and every codeword containing k contains X or Y ("cover").

Steps:
- Witness p: a point of W1 & U_k & U_X (needs a codeword containing S1 u X u {k}). Witness q: a point of W3 & U_k & U_Y (codeword containing S3 u Y u {k}).
- [p,q] lies in U_k (convexity). Each point of [p,q] has a codeword containing k, which contains X or Y, so [p,q] is covered by the open sets U_X and U_Y.
- If [p,q] missed U_X & U_Y, it would split into two disjoint nonempty open pieces (p in U_X only, q in U_Y only), impossible for a segment. So some r in [p,q] lies in U_X & U_Y, hence in W2.
- The line L through p and q meets W1 (at p), W2 (at r, which is on L because r is on the segment) and W3 (at q). LSW Lemma 3.2 gives s in L & T.
- s is not in [p,q], because [p,q] is inside U_k and T & U_k is empty.
- If s is beyond q, then q lies between r and s, both in W2, so q is in W2 & W3 = T, but q is in U_k: contradiction. If s is beyond p, then p lies between s and r, so p is in W1 & W2 = T: contradiction.
- Hence no such configuration exists, so the code is not convex.

Note on the plan: its text needs r to lie on the line through p and q (it does, because r is on the segment [p,q]) and it needs the outer-piece argument above. Both are now stated explicitly.

## 2. Validation of the search

Two one-off scripts (not included): search_general.py enumerates every wall k, transit pair (X,Y), W-triple (S1,S2,S3) with S2 inside X u Y, and checks every condition above by bitmasks. sg_check.py runs the same test on the LSW example code {2345,123,134,145,13,14,23,34,45,3,4,empty}. It finds the LSW configuration (wall 1, X = 3, Y = 4, W1 = U2 or U23, W2 = U34, W3 = U5 or U45), so the search is not vacuous.

Result on the eight codes: 0 configurations for each. The LSW-style lemma-based argument therefore cannot be closed for any of them, with any choice of U-set walls, W's and transit sets.

Scope caveat: this is an exhaustive check of the single-line, single-wall, transit family, with W's of the form U_S. It does not rule out triangle versions (three witness points, three segments), W's that are not U-sets, or arguments using the 1D interval structure of lines. Those were not explored.

## 3. Per-code findings

Shared reason a wall fails: if {k} is itself a codeword, no cover exists for wall k, because the codeword {k} contains neither X nor Y. Walls inside the triple are excluded automatically.

### C5-007
- Code: empty 1 2 6 12 13 14 35 134 135 146 2356. Maximal: 12 134 135 146 2356.
- Template setups (4): W = U2,U3,U6 walls 1 and 4; W = U2,U5,U6 wall 1; W = U2,U6,U35 wall 1. Triple = {2356}.
- Covers exist only at walls 3, 4, 5. Wall 1 fails because {1} is a codeword.
- Verdict: NO SETUP WORKS. Every template setup with wall 1 fails at the cover step; wall 4 has covers, but no W-choice satisfies the witness and pairwise conditions.

### C5-005
- Code: empty 1 2 3 4 12 15 34 56 135 156 2456. Maximal: 12 135 156 2456 34.
- Template setups (4): W = U2,U4,U5 walls 1 and 3; W = U2,U4,U6 wall 1; W = U2,U4,U56 wall 1. Triple = {2456}.
- Singletons 1, 2, 3, 4 are codewords, so walls 1, 3 and 2, 4 admit no cover. The only walls with covers (5, 6) lie inside the triple 2456, so they are not valid walls.
- Verdict: NO SETUP WORKS. No valid wall admits a transit cover.

### C5-018
- Code: empty 1 2 12 34 56 134 156 235 2345 2356. Maximal: 12 134 156 2345 2356.
- Template setups (1): W = U2,U3,U5 wall 1. Triple = {235, 2356, 2345}.
- Wall 1 fails because {1} is a codeword. Walls 4 and 6 have covers (24 words each), but the search finds no W-choice satisfying all conditions.
- Verdict: NO SETUP WORKS.

### C5-042
- Code: empty 1 2 4 12 13 14 15 23 24 46 123 124 135 1456 2346. Maximal: 123 124 135 1456 2346.
- Template setups (17): several with walls 1, 2, 3, 5, 6 and triples 2346, 1456, 123, 124. Wall 3 with W = U12,U13,U23 is the only one where the transit pair (13, 23) covers all codewords through 3, and that setup is not valid: the triple codeword 123 contains 3, so 3 is inside the triple.
- Singletons 1, 2, 4 kill walls 1, 2, 4. Covers exist at walls 3, 5, 6, but no valid wall combines a cover with a triple avoiding it and witnesses for all W choices.
- Verdict: NO SETUP WORKS.

### C5-050
- Code: empty 1 4 12 23 35 56 123 124 156 235 3456. Maximal: 123 124 156 235 3456.
- Template setups (8): walls 1 and 2 with W = U3,U4,U6 / U3,U4,U56 / U4,U6,U35 / U4,U35,U56. Triple = {3456}.
- Singletons 1 and 4 kill walls 1 and 4. Walls 3, 5, 6 lie inside the triple 3456, so the only valid wall is 2. Wall 2 has covers, but no W-choice meets the witness and pairwise conditions. Covers at 3, 5, 6 are not usable.
- Verdict: NO SETUP WORKS.

### C5-060
- Code: empty 1 3 12 13 14 23 35 36 123 124 134 1345 1346 2356. Maximal: 123 124 1345 1346 2356.
- Template setups (19): walls 1, 4, 5, 6 with triples 2356 and 123. Wall k is valid only for triples not containing k: wall 1 and 4 for triple 2356, walls 4, 5, 6 for triple 123.
- Singletons 1, 3 kill walls 1 and 3. Covers exist at walls 2, 4, 5, 6, but none combines with a valid wall and witnesses for any W choice.
- Verdict: NO SETUP WORKS.

### C5-076
- Code: empty 2 5 12 14 23 123 145 236 246 1246 2346 2356. Maximal: 123 1246 145 2346 2356.
- Template setups (7): walls 3 and 5 with triples 1246 (W = U6,U12,U14 etc.).
- Singletons 2 and 5 kill walls 2 and 5. Covers exist at walls 1, 3, 4, 6; wall 3 and 5 are the template walls. For wall 3 the cover exists (24 covers), but the search finds no W-choice with valid witnesses and triple avoidance.
- Verdict: NO SETUP WORKS.

### C5-090
- Code: empty 1 2 3 4 12 13 23 34 123 145 146 245 1245 1346 1456 2345. Maximal: 123 1245 1346 1456 2345.
- Template setups (28): walls 1, 2, 3, 4, 5, 6 with triples 2345, 1346, 123, 1245.
- Singletons 1, 2, 3, 4 kill walls 1 to 4. Covers exist only at walls 5 and 6 (28 and 68 covers). Wall 5 is valid only for triples 1346 and 123; wall 6 only for 2345, 1245 and 123. The search finds no W-choice satisfying all conditions for either.
- Verdict: NO SETUP WORKS. This code has the most setups (28) but none passes the search.

## 4. Summary
- All eight: NO SETUP WORKS (for the LSW lemma-based family; see caveat in section 2).
- No PROOF or PARTIAL verdicts. No GAP markers were needed because no configuration was found that could be carried through.
