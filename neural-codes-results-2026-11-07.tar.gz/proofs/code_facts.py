"""Usage: python3 proofs/code_facts.py C5-068
Prints the code, its maximal codewords, and for any set X you ask (extra args, like 34 or 245):
which codewords contain X. Example: python3 proofs/code_facts.py C5-068 24 13"""
import json, sys
import os; ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
codes = {c["id"]: c for c in json.load(open(os.path.join(ROOT, "jeffs_96_codes.json")))["codes"]}
c = codes[sys.argv[1]]
words = [frozenset(w) for w in c["codewords"]]
s = lambda w: "".join(map(str, sorted(w))) or "empty"
print("code:", " ".join(s(w) for w in sorted(words, key=lambda w: (len(w), sorted(w)))))
print("maximal:", " ".join(s(frozenset(m)) for m in c["maximal"]))
for x in sys.argv[2:]:
    X = frozenset(int(ch) for ch in x)
    print(f"codewords containing {x}:", " ".join(s(w) for w in words if X <= w) or "NONE (U_X is empty)")
