"""morph_absorb.py - Jeffs morphism images + Prabhakar absorption / split-cover on every image.
Soundness: image of a convex code under a trunk morphism is convex (Jeffs Thm 1.3, Prop 2.12); the
empty word is in every image (the empty codeword lies in no nonempty trunk); absorption.flagged and
split_cover are non-convexity certificates for codes (with the empty word). So any flagged image => original NON-convex.
Usage: python3 proofs/morph_absorb.py KMAX ids...   (no ids = all 96)
"""
import sys, json, time
import os; ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)
from itertools import combinations
from multiprocessing import Pool
from morph_check import all_trunks, image
from neuralcodes import make_code
from absorption import flagged as abs_flagged
from prabhakar_checks import split_cover

def canon(img):
    sig = {}
    for w in img:
        for j in w: sig.setdefault(j, []).append(len(w))
    order = sorted(sig, key=lambda j: (sorted(sig[j]), j))
    m = {j: i for i, j in enumerate(order)}
    return frozenset(frozenset(m[j] for j in w) for w in img)

def run(args):
    cid, cw, kmax = args
    code = make_code(cw); tr = all_trunks(code); T = list(tr)
    seen = set(); n = 0; hit = None; t0 = time.time()
    for m in range(1, min(kmax, len(T)) + 1):
        for pick in combinations(range(len(T)), m):
            img = frozenset(image(code, [T[i] for i in pick]))
            key = canon(img)
            if key in seen: continue
            seen.add(key); n += 1
            words = [sorted(w) for w in img]
            a = abs_flagged(words)
            s = split_cover(words) if a is None else None
            if a is not None or s is not None:
                hit = dict(trunk_faces=[sorted(tr[T[i]]) for i in pick], image=sorted(sorted(w) for w in img),
                           absorption=a, split_cover=s)
                break
        if hit: break
    return cid, n, hit, time.time() - t0, len(T)

if __name__ == "__main__":
    kmax = int(sys.argv[1]); only = set(sys.argv[2:])
    codes = json.load(open(os.path.join(ROOT, 'jeffs_96_codes.json')))['codes']
    jobs = [(c['id'], c['codewords'], kmax) for c in codes if not only or c['id'] in only]
    with Pool(2) as p:
        for cid, n, hit, dt, nt in p.imap_unordered(run, jobs):
            print(cid, "FLAGGED" if hit else "none", f"images={n} trunks={nt} {dt:.0f}s", json.dumps(hit) if hit else "", flush=True)
