"""triangle_cross.py - NEW 'triangle crossing' non-convexity criterion (extension of Prabhakar's absorption rule).

Setup (any convex realization U_1..U_n of C in R^d; the empty word is allowed). Pick three codewords s,t,u and
points p,q,r with those codewords (they need not be non-collinear). The triangle T=conv{p,q,r} lies in a plane.
The boundary of T is the three segments pq, qr, rp. Along each segment, Lemma 8.1 (absorption.py) gives a loop-erased
simple sequence of codewords, each entry realised at a point of the segment, in order along the segment. Concatenate
the three sequences cyclically into a list L (entries are points on the boundary circle of the convex planar set T,
in weakly cyclic order).

CROSSING RULE. For list entries i<j<k<l with words a,b,c,d at boundary points P_i,P_j,P_k,P_l: the chords [P_i,P_k]
and [P_j,P_l] of the planar convex set T intersect, at a point x. x lies in U_(a&c) (convexity, chord ends in those)
and in U_(b&d). So some codeword w contains R=(a&c)|(b&d); moreover x is in conv(U_alpha u U_beta) for alpha in a,
beta in c, so Lemma 4.1 (absorption) applies to x with w: for mu in w, alpha in a, beta in c with
Tk(mu+alpha)=Tk(mu+beta)!=empty I need alpha,beta in w; same for (b,d). If no codeword w satisfies this, the
combination of three sequences is impossible. If for some (s,t,u) NO triple of valid sequences is crossing-consistent,
C is NOT convex.
Usage: python3 proofs/triangle_cross.py ids...
"""
import sys, json, time
import os; ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)
from itertools import combinations
from absorption import Absorb


class Tri(Absorb):
    def __init__(self, cw):
        super().__init__(cw)
        self.cross = {}
        self.seqs = {}

    def all_seqs(self, s, t, cap=200000):
        k = (s, t)
        if k in self.seqs: return self.seqs[k]
        out = []
        if self.ok([], s):
            def dfs(seq):
                if len(out) > cap: raise RuntimeError("too many sequences")
                if seq[-1] == t:
                    out.append(tuple(seq)); return
                for w in self.nbrs[seq[-1]]:
                    if w not in seq and self.ok(seq, w):
                        dfs(seq + [w])
            dfs([s])
        self.seqs[k] = out
        return out

    def abs_ok(self, va, w, vc):
        return not self.r3(va, w, vc) and not self.r3(vc, w, va)

    def cross_ok(self, a, b, c, d):
        key = (a, b, c, d)
        if key not in self.cross:
            R = (a & c) | (b & d)
            self.cross[key] = any(R <= w and self.abs_ok(a, w, c) and self.abs_ok(b, w, d) for w in self.code)
        return self.cross[key]

    def L_ok_new(self, L, start):
        """check every 4-tuple of L whose last index >= start (earlier ones were checked)."""
        n = len(L)
        for l in range(max(start, 3), n):
            for i, j, k in combinations(range(l), 3):
                if not self.cross_ok(L[i], L[j], L[k], L[l]): return False
        return True

    def tri_feasible(self, s, t, u):
        S1, S2, S3 = self.all_seqs(s, t), self.all_seqs(t, u), self.all_seqs(u, s)
        for x in S1:
            for y in S2:
                L = list(x) + list(y)
                if not self.L_ok_new(L, 0): continue
                for z in S3:
                    L2 = L + list(z)
                    if self.L_ok_new(L2, len(L)): return (x, y, z)
        return None

    def flagged_triangle(self):
        for s, t, u in combinations(self.code, 3):
            if self.tri_feasible(s, t, u) is None:
                return [sorted(s), sorted(t), sorted(u)]
        return None


def flagged_tri(cw): return Tri(cw).flagged_triangle()

if __name__ == "__main__":
    codes = {c["id"]: c for c in json.load(open(os.path.join(ROOT, "jeffs_96_codes.json")))["codes"]}
    for cid in sys.argv[1:] or sorted(codes):
        t0 = time.time()
        try: r = flagged_tri(codes[cid]["codewords"])
        except RuntimeError as e: r = "CAP " + str(e)
        print(cid, codes[cid]["source_id"], r, f"{time.time()-t0:.1f}s", flush=True)
