# C5-068 has no convex open realization in the plane (hand proof)

Code C5-068: {3, 5, 6, 12, 14, 24, 123, 124, 145, 246, 356, empty}
Maximal: 123, 124, 145, 246, 356.

Tool used: Sunflower Theorem (Jeffs, "Sunflowers of convex open sets", Cor. 2.1; restated as
Thm 5.2 in arXiv:1909.13406). If U1..U_{d+1} are convex open sets in R^d whose pairwise
intersections all equal their common intersection U (nonempty), and p_i is in U_i, then
conv{p_1..p_{d+1}} contains a point of U.   [statement taken from summaries; confirm in the PDF]

Proof. Suppose convex open U1..U6 in R^2 realize C5-068.

1. Sunflower. The codewords containing {3,5}, {3,6} or {5,6} are only 356. So
   U3&U5 = U3&U6 = U5&U6 = U356, which is nonempty. With d = 2 and three petals, the theorem applies.
2. Witness points. Pick a with pattern 123, b with pattern 145, c with pattern 246.
   Then a is in U3, b in U5, c in U6. So the triangle T = conv{a,b,c} contains a point o of U356.
3. Each side of T passes through U124.
   - Side ab lies in U1 (both ends are in U1). Every codeword with 1 (12,14,123,124,145) has a 2 or a 4,
     so the side is covered by the two open sets U12 and U14. a is in U12, b is in U14, and a segment is
     connected, so the two must overlap on it: some point x of ab is in U124.
   - Side ac lies in U2. Codewords with 2 (12,24,123,124,246) all have 1 or 4. a in U12, c in U24,
     so some y on ac is in U124.
   - Side bc lies in U4. Codewords with 4 (14,24,124,145,246) all have 1 or 2. b in U14, c in U24,
     so some z on bc is in U124.
4. Cut T into four triangles: axy, bxz, cyz, xyz. Each lies in one convex set:
   axy in U12 (a, x, y are all in U12), bxz in U14, cyz in U24, xyz in U124.
5. So o is in U12, U14 or U24, and also in U356. Its codeword would contain 12356, 13456 or 23456.
   None of those is a codeword. Contradiction.

So C5-068 cannot be drawn with convex open sets in the plane. (This matches the computer: no octagon
drawing on 0..8 and no 8-direction drawing found.) It does NOT show C5-068 is non-convex: in R^3 the
sunflower theorem needs 4 petals, and I only have 3. This is the same situation as Jeffs' T3, which
is convex in R^3 but not in R^2. So C5-068 is a strong candidate for a 3D drawing.

Session 1 found the same near miss for the line version.
