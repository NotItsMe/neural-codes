"""lsw_template.py - look for the SHAPE of the Lienkaemper-Shiu-Woodstock argument in a code.
Need faces t1, t2, t3 (so W_i = U_ti is convex) with
  (a) W1 & W2 & W3 nonempty: some codeword contains t1|t2|t3
  (b) every pairwise intersection equals the triple one: the codewords containing ti|tj are
      exactly the codewords containing t1|t2|t3   (LSW Lemma 3.2 then says: a line meeting
      all three W's meets the triple part)
  (c) a "wall" neuron k: no codeword contains k and t1|t2|t3, but W1, W3 each meet U_k
      (so a segment inside U_k from W1 to W3 never touches the triple part).
What is still left for a later session: show the segment must also pass through W2.
Usage: python3 proofs/lsw_template.py C5-068 [more ids]"""
import json, sys
import os; ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
from itertools import combinations
codes = {c["id"]: c for c in json.load(open(os.path.join(ROOT, "jeffs_96_codes.json")))["codes"]}
s = lambda w: "".join(map(str, sorted(w))) or "empty"

def run(cid):
    words = [frozenset(w) for w in codes[cid]["codewords"]]
    nz = [w for w in words if w]
    faces = sorted({frozenset(x) for w in nz for k in range(1, len(w) + 1) for x in combinations(sorted(w), k)},
                   key=lambda f: (len(f), sorted(f)))
    cont = lambda X: frozenset(w for w in words if X <= w)
    neurons = sorted(set().union(*words))
    hits = []
    for t1, t2, t3 in combinations(faces, 3):
        T = t1 | t2 | t3
        top = cont(T)
        if not top:
            continue
        if any(cont(a | b) != top for a, b in ((t1, t2), (t1, t3), (t2, t3))):
            continue
        if len({t1, t2, t3}) < 3 or any(cont(t) == top for t in (t1, t2, t3)):
            continue  # a W equal to the triple part makes the lemma empty
        for k in neurons:
            if any(k in w for w in top):
                continue
            ends = [t for t in (t1, t2, t3) if cont(t | {k})]
            if len(ends) >= 2:
                hits.append((s(t1), s(t2), s(t3), k, [s(e) for e in ends], " ".join(s(w) for w in top)))
    return hits

for cid in sys.argv[1:]:
    h = run(cid)
    print(f"{cid}: {len(h)} candidate setups")
    for x in h[:25]:
        print(f"  W=U{x[0]},U{x[1]},U{x[2]}  wall neuron {x[3]}  (W's meeting U{x[3]}: {x[4]})  triple part = codewords {x[5]}")
