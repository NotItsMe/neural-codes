# Plan: try to copy the LSW "segment" proof onto open neural codes

## Background
A neural code C on neurons 1..6 is a set of codewords (subsets of neurons). C is CONVEX if there are
open convex sets U1..U6 in some R^d such that the set of neurons whose regions contain a point p,
taken over all points p, is exactly C. (The empty word means "a point in none of the regions".)
Notation: U_X = intersection of U_i for i in X. Key facts used throughout:
- U_X is convex and open (intersection of convex open sets).
- U_X is nonempty iff some codeword contains X. U_X is the union of the "atoms" of the codewords
  containing X. So U_X = U_Y exactly when the codewords containing X are the codewords containing Y.
- A segment between two points of a convex set stays inside it.
- Along a segment, the codeword you see changes only when you cross a region boundary, and every
  point shows some codeword of C.

LSW Lemma 3.2 (Lienkaemper-Shiu-Woodstock 2017): if W1, W2, W3 are convex open, W1&W2&W3 nonempty,
and W1&W2 = W1&W3 = W2&W3 = W1&W2&W3, then every LINE meeting all three W's meets W1&W2&W3.

LSW Theorem 3.1 (how it was used). Code {2345,123,134,145,13,14,23,34,45,3,4,empty}.
Take p in U123, q in U145. The segment [p,q] lies in U1. Inside U1 the only codewords are
123,134,145,13,14 so walking from 123 to 145 you must pass through a point whose codeword contains
both 3 and 4 (going from "has 3, no 4" to "has 4, no 3" inside U1 you can only switch through 134,
since 1 alone is not a codeword: every point in U1 is in U3 or U4, and U13 and U14 are open, so the
segment cannot jump from one to the other without passing through U134). Call that point r.
W1=U23 contains p, W2=U34 contains r, W3=U45 contains q; all pairwise intersections equal U2345.
By the lemma the line through p, q meets U2345. But the segment [p,q] is inside U1 and 1 is not in
2345, so the meeting point is outside the segment, and the paper rules out both outer pieces
(a point beyond p or beyond q, together with r, would force a forbidden codeword by convexity).
Contradiction, so not convex. The whole proof is: witness points, segments, which codewords can
appear along a segment inside some U_X, then the lemma.

## Tools (run from the bundle folder)
- `python3 proofs/code_facts.py C5-xxx 24 13` prints the code, maximal words, and which codewords
  contain each set you list (here {2,4} and {1,3}).
- `python3 proofs/lsw_template.py C5-xxx` lists every choice of W1,W2,W3 (as U_t's) that satisfies
  the lemma's hypotheses, plus a "wall" neuron k: no codeword contains k together with the triple,
  but at least two W's meet U_k. WARNING: these setups also show up in codes that ARE convex, so a
  setup alone proves nothing. The real work is the step "the segment / line is forced through
  all three W's AND cannot reach the triple part".

## Method
The open codes were split into five groups (`group1.txt` to `group5.txt` and `assign1.txt` to `assign5.txt`), one working session per group. For each code, in order:
1. Look at its setups. Pick the most promising one and try to write the full LSW-style argument:
   witness points, segments, exactly which codewords can appear along each segment (justified with
   code_facts.py output), the lemma, and the final contradiction (including the parts of the line
   OUTSIDE the segment).
2. Also try a triangle version (three witness points, three segments) or other choices.
3. Be strict. Every step must follow from the facts above. If a step needs something that can't be
   justified, stop and mark it `GAP:` with exactly what is missing. A clean, honest GAP is worth
   more than a fake proof. No code is called non-convex unless every step is justified.
4. Work only from the code itself, without looking at certificates/, poly_results/, sat_results/
   or any results/log files.

Each code gets a verdict:
- `PROOF` (complete argument, no gaps)
- `PARTIAL` (argument with clearly marked GAPs)
- `NO SETUP WORKS` (why the segment can't be forced in any setup)

Results for group N are in `session<N>.md`, one section per code.
