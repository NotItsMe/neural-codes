"""Tests for the exact (no-timeout-needed) octagon decider. Run: python3 test_oct_exact.py"""
import json
from oct_exact import decide
from oct_checker import check

def ok(name, cond):
    print(("PASS  " if cond else "FAIL  ") + name)
    assert cond, name

codes = {c["id"]: c for c in json.load(open("jeffs_96_codes.json"))["codes"]}
w = lambda cid: codes[cid]["codewords"]

for solver in ("z3", "cvc5"):
    # 1. Hollow triangle: drawable with a slanted edge -> YES, and the referee agrees.
    r, cert = decide([[1], [2], [3], [1, 2], [1, 3], [2, 3]], K=3, solver=solver)
    ok(f"[{solver}] hollow triangle is drawable", r == "SAT" and check([[1],[2],[3],[1,2],[1,3],[2,3]], cert)[0])

    # 2. {12, 23, 1, 3}: the region of 2 would be split in two -> no drawing at all -> NO.
    r, _ = decide([[1, 2], [2, 3], [1], [3]], K=4, solver=solver)
    ok(f"[{solver}] disconnected code {{12,23,1,3}} has no drawing", r == "UNSAT")

    # 3. Codes I already drew on the 0..6 grid must come back YES, referee-checked.
    for cid in ["C5-002", "C5-022"]:
        r, cert = decide(w(cid), K=6, solver=solver)
        ok(f"[{solver}] {cid} (already drawn on 0..6) is YES", r == "SAT" and check(w(cid), cert)[0])

    # 4. C5-068: the counterexample-loop search already proved NO on 0..6; must agree.
    r, _ = decide(w("C5-068"), K=6, solver=solver, timeout_s=3600)
    ok(f"[{solver}] C5-068 is NO on 0..6 (agrees with earlier search)", r == "UNSAT")

print("\nAll exact-decider tests passed.")
