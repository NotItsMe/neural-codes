"""
oct_checker.py - REFEREE for "octagon" drawings in the plane.

Each neuron's region is an open convex polygon cut out by four kinds of edges:
    lo_x < x < hi_x,   lo_y < y < hi_y,   lo_s < x+y < hi_s,   lo_d < x-y < hi_d
(up to 8 sides: a box with its corners clipped at 45 degrees; triangles and hexagons
fit too). Unlike boxes, these can make a "hollow triangle", so the Helly rule no
longer blocks them.

Why the check is exact: draw every edge line of every region. Those lines cut the
plane into vertices, open edge pieces and open faces, and on each piece every neuron
is either fully in or fully out. I test one exact point (Fractions) in every piece:
 - cut the plane into vertical slabs at the x-coordinate of every vertex,
 - on each slab's middle line, test every crossing with a line and every gap between,
 - on each vertical line through a vertex, do the same.
Every face crosses some slab's middle line, every slanted or flat edge does too, and
every vertex and vertical edge sits on one of the vertical lines, so nothing is skipped.
"""
from fractions import Fraction as F
from itertools import combinations

FORMS = ("x", "y", "x+y", "x-y")


def value(form, p):
    x, y = p
    return {"x": x, "y": y, "x+y": x + y, "x-y": x - y}[form]


def load(cert):
    """cert: {neuron: {"x": [lo, hi], "y": [...], "x+y": [...], "x-y": [...]}}; missing form = no limit."""
    regions = {}
    for n, r in cert.items():
        reg = {}
        for f in FORMS:
            if f in r and r[f] is not None:
                lo, hi = F(r[f][0]), F(r[f][1])
                assert lo < hi, f"neuron {n}: empty range on {f}"
                reg[f] = (lo, hi)
        regions[int(n)] = reg
    return regions


def inside(reg, p):
    return all(lo < value(f, p) < hi for f, (lo, hi) in reg.items())


def pattern_at(p, regions):
    return frozenset(n for n, reg in regions.items() if inside(reg, p))


def lines(regions):
    """Every edge line as (form, constant)."""
    out = set()
    for reg in regions.values():
        for f, (lo, hi) in reg.items():
            out.add((f, lo)); out.add((f, hi))
    return out


def y_on(line, x):
    """y where a non-vertical line crosses the vertical line at x."""
    f, c = line
    return {"y": c, "x+y": c - x, "x-y": x - c}[f]


def meet(a, b):
    """Intersection point of two lines, or None if parallel."""
    (fa, ca), (fb, cb) = a, b
    if fa == fb:
        return None
    if "x" in (fa, fb) and fa != fb and (fa == "x" or fb == "x"):
        vx = ca if fa == "x" else cb
        other = b if fa == "x" else a
        return (vx, y_on(other, vx))
    # two non-vertical lines: y = m1 x + k1, y = m2 x + k2
    def mk(l):
        f, c = l
        return {"y": (F(0), c), "x+y": (F(-1), c), "x-y": (F(1), -c)}[f]
    m1, k1 = mk(a); m2, k2 = mk(b)
    x = (k2 - k1) / (m1 - m2)
    return (x, m1 * x + k1)


def column_points(x, nonvertical):
    """Points on the vertical line at x: each crossing, each gap between, and past both ends."""
    ys = sorted({y_on(l, x) for l in nonvertical})
    if not ys:
        return [(x, F(0))]
    pts = [(x, ys[0] - 1)]
    for i, y in enumerate(ys):
        pts.append((x, y))
        if i + 1 < len(ys):
            pts.append((x, (y + ys[i + 1]) / 2))
    pts.append((x, ys[-1] + 1))
    return pts


def produced_code(regions):
    L = lines(regions)
    nonvertical = [l for l in L if l[0] != "x"]
    xs = {c for f, c in L if f == "x"}
    for a, b in combinations(L, 2):
        p = meet(a, b)
        if p is not None:
            xs.add(p[0])
    xs = sorted(xs) or [F(0)]
    columns = [xs[0] - 1] + xs + [xs[-1] + 1]
    columns += [(xs[i] + xs[i + 1]) / 2 for i in range(len(xs) - 1)]
    found = {}
    for x in columns:
        for p in column_points(x, nonvertical):
            pat = pattern_at(p, regions)
            if pat not in found:
                found[pat] = p
    return found


def check(target_codewords, cert):
    target = {frozenset(c) for c in target_codewords} | {frozenset()}
    regions = load(cert)
    assert set(regions) == set().union(*target), "need exactly one region per neuron"
    found = produced_code(regions)
    missing = target - set(found)
    extra = set(found) - target
    return (not missing and not extra), missing, extra, found


def show(s):
    return sorted("".join(map(str, sorted(c))) or "{}" for c in s)
