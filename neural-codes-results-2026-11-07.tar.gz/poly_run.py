"""
poly_run.py - run the exact decider on many codes and save every answer with its evidence.
Run: python3 poly_run.py jeffs_96_codes.json NDIRS K [ids...]      (NDIRS = 3, 4 or 8)
Writes poly_results/<id>_D<NDIRS>_K<K>.json. YES -> drawing (referee-checked).
NO -> drat-trim verdict + size and sha256 of the proof; the proof file itself is deleted
(it is huge) and can be rebuilt exactly by rerunning CaDiCaL on the saved .cnf.
"""
import hashlib, json, os, sys, time
from poly import DIRS3, DIRS4, DIRS8, decide, check

DIRS = {3: DIRS3, 4: DIRS4, 8: DIRS8}


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    path, nd, K = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    dirs = DIRS[nd]
    codes = {c["id"]: c for c in json.load(open(path))["codes"]}
    os.makedirs("poly_results", exist_ok=True)
    for cid in sys.argv[4:]:
        stem = f"poly_results/{cid}_D{nd}_K{K}"
        if os.path.exists(stem + ".json") and json.load(open(stem + ".json"))["result"] != "UNKNOWN":
            continue
        t0 = time.time()
        r, cert, pv = decide(codes[cid]["codewords"], K, dirs, stem,
                             timeout_s=float(os.environ.get("TLIM", 0)) or None,
                             proof=os.environ.get("PROOF", "1") == "1")
        out = {"id": cid, "directions": [list(d) for d in dirs], "K": K, "result": r,
               "seconds": round(time.time() - t0, 1)}
        if r == "SAT":
            assert check(codes[cid]["codewords"], cert, dirs)[0], f"{cid}: drawing failed the referee"
            out["drawing"] = cert
        elif r == "UNSAT":
            out["proof_verified_by_drat_trim"] = pv          # None = searched without a proof file
            pf = stem + ".drat"
            if os.path.exists(pf):
                out["proof_file"] = {"bytes": os.path.getsize(pf), "sha256": sha(pf),
                                     "rebuild": f"tools/cadical --no-binary -q {os.path.basename(stem)}.cnf proof.drat"}
                os.remove(pf)
        json.dump(out, open(stem + ".json", "w"), indent=1)
        print(cid, f"D={nd} K={K}", r, f"proof_verified={pv}" if r == "UNSAT" else "",
              f"({out['seconds']}s)", flush=True)


if __name__ == "__main__":
    main()
