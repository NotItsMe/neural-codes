"""Tests for the octagon referee. Run: python3 test_oct_checker.py"""
import json
from oct_checker import check, show

def code(*w):
    return [[int(c) for c in x] for x in w]

def expect(name, target, cert, should_pass, extra=None, missing=None):
    ok, miss, ext, _ = check(target, cert)
    good = ok == should_pass
    if extra is not None: good &= show(ext) == extra
    if missing is not None: good &= show(miss) == missing
    print(("PASS  " if good else "FAIL  ") + name + ("" if ok else f"   (missing {show(miss)}, extra {show(ext)})"))
    assert good, name

BIG = 100
def box(x, y):
    return {"x": x, "y": y}

# 1. Boxes are a special case: the verified C5-004 drawing must still pass.
c4 = next(c for c in json.load(open("jeffs_96_codes.json"))["codes"] if c["id"] == "C5-004")
c4cert = {1: box([0, 9], [0, 11]), 2: box([0, 10], [4, 11]), 3: box([0, 10], [2, 3]),
          4: box([9, 11], [2, 11]), 5: box([9, 11], [3, 11]), 6: box([9, 11], [2, 4])}
expect("C5-004 boxes still pass", c4["codewords"], c4cert, True)

# 2. The hollow triangle {1,2,3,12,13,23}: impossible for boxes, possible with a slanted edge.
#    1: y<1, 2: x<1, 3: x+y>3 (inside a big square). Pairs overlap, all three never do.
sq = {"x": [-BIG, BIG], "y": [-BIG, BIG]}
tri = {1: {**sq, "y": [-BIG, 1]}, 2: {**sq, "x": [-BIG, 1]}, 3: {**sq, "x+y": [3, 2 * BIG]}}
expect("hollow triangle realized", code("1", "2", "3", "12", "13", "23"), tri, True)

# 3. Move the slanted edge to x+y>1.5: now all three overlap near (0.9, 0.9) -> extra 123.
tri2 = dict(tri); tri2[3] = {**sq, "x+y": [1.5, 2 * BIG]}
expect("triangle broken: 123 leaks", code("1", "2", "3", "12", "13", "23"), tri2, False, extra=["123"])

# 4. Slanted boundary sliver: 1: x+y<2, 2: x+y>2, 3: big square. The line x+y=2
#    is covered by 3 only -> extra {3}.
sl = {1: {**sq, "x+y": [-3 * BIG, 2]}, 2: {**sq, "x+y": [2, 3 * BIG]}, 3: dict(sq)}
expect("slanted sliver caught", code("13", "23"), sl, False, extra=["3"])

# 5. A pattern that exists at ONE point only: 1: x<0, 2: x>0, 3: y<0, 4: y>0, 5: square.
#    The origin is in 5 alone, and nowhere else is. The referee must still see {5}.
from oct_checker import produced_code, load
pt = {1: {**sq, "x": [-BIG, 0]}, 2: {**sq, "x": [0, BIG]},
      3: {**sq, "y": [-BIG, 0]}, 4: {**sq, "y": [0, BIG]}, 5: dict(sq)}
found = produced_code(load(pt))
good = frozenset({5}) in found and found[frozenset({5})] == (0, 0)
print(("PASS  " if good else "FAIL  ") + "single-point pattern {5} found at the origin")
assert good

# 6. Same idea on a 45-degree crossing: 1: x+y<0, 2: x+y>0, 3: x-y<0, 4: x-y>0, 5: square.
pt2 = {1: {**sq, "x+y": [-3*BIG, 0]}, 2: {**sq, "x+y": [0, 3*BIG]},
       3: {**sq, "x-y": [-3*BIG, 0]}, 4: {**sq, "x-y": [0, 3*BIG]}, 5: dict(sq)}
found = produced_code(load(pt2))
good = frozenset({5}) in found
print(("PASS  " if good else "FAIL  ") + "single-point pattern on slanted lines found")
assert good

print("\nAll octagon referee tests passed.")
