"""
oct_sat.py - the same exact question as oct_exact.py ("is there an octagon drawing with
whole-number limits on 0..K?"), written as plain true/false clauses (CNF) for a SAT
solver. Built separately from the Z3 version, so it is an independent second opinion.

The big win: when the answer is NO, the SAT solver writes a PROOF FILE (DRUP format),
and the small, well-tested checker drat-trim re-checks that proof step by step. So a
NO does not have to be taken on trust: anyone can re-run drat-trim on the two files.

Encoding (order encoding): for every limit L (a whole number in [a, b]) I keep
switches "L <= t" for t = a..b-1, chained so L<=t implies L<=t+1.
A point with value v on some form is strictly inside (lo, hi) exactly when
    lo <= ceil(v) - 1   and   NOT (hi <= floor(v)).

Run: python3 oct_sat.py jeffs_96_codes.json K [ids...]
Writes sat_results/<id>_K<K>.json, and for NO also .cnf and .drup proof files.
"""
import json, math, os, subprocess, sys, time
from itertools import count
from pysat.solvers import Glucose4
from oct_search import grid_points
from oct_checker import FORMS, check

DRAT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tools", "drat-trim")
RNG = lambda K: {"x": (0, K), "y": (0, K), "x+y": (0, 2 * K), "x-y": (-K, K)}
TRUE, FALSE = "T", "F"


def fval(form, p):
    x, y = p
    return {"x": x, "y": y, "x+y": x + y, "x-y": x - y}[form]


class CNF:
    def __init__(self):
        self.n = count(1)
        self.clauses = []

    def var(self):
        return next(self.n)

    def add(self, lits):
        if TRUE in lits:
            return                                   # clause already satisfied
        lits = [l for l in lits if l != FALSE]
        assert lits, "empty clause: the encoding forced a contradiction directly"
        self.clauses.append(lits)


def neg(l):
    return FALSE if l == TRUE else TRUE if l == FALSE else -l


def build(codewords, K):
    code = {frozenset(c) for c in codewords} | {frozenset()}
    neurons = sorted(set().union(*code))
    cnf = CNF()
    le = {}                      # le[(kind, n, f)][t] = literal for "limit <= t"

    def le_lit(key, t):
        a, b = key[3]
        if t < a:
            return FALSE
        if t >= b:
            return TRUE
        return le[key[:3]][t]

    keys = []
    for n in neurons:
        for f in FORMS:
            a, b = RNG(K)[f]
            for kind in ("lo", "hi"):
                le[(kind, n, f)] = {t: cnf.var() for t in range(a, b)}
                for t in range(a, b - 1):            # L<=t  ->  L<=t+1
                    cnf.add([-le[(kind, n, f)][t], le[(kind, n, f)][t + 1]])
            keys.append((n, f, (a, b)))
    L = lambda n, f, t: le_lit(("lo", n, f, RNG(K)[f]), t)
    H = lambda n, f, t: le_lit(("hi", n, f, RNG(K)[f]), t)

    for n, f, (a, b) in keys:                        # lo < hi:  hi<=t -> lo<=t-1
        for t in range(a, b + 1):
            cnf.add([neg(H(n, f, t)), L(n, f, t - 1)])

    pts = grid_points(K)
    inside = {}
    for i, p in enumerate(pts):
        for n in neurons:
            lits = []
            for f in FORMS:
                v = fval(f, p)
                lits.append(L(n, f, math.ceil(v) - 1))
                lits.append(neg(H(n, f, math.floor(v))))
            b = cnf.var()                            # b <-> AND(lits)
            for l in lits:
                cnf.add([-b, l])
            cnf.add([b] + [neg(l) for l in lits])
            inside[n, i] = b

    shows = {}
    for i in range(len(pts)):
        for c in code:
            s = cnf.var()                            # s -> pattern at point i is exactly c
            for n in neurons:
                cnf.add([-s, inside[n, i] if n in c else -inside[n, i]])
            shows[c, i] = s
        cnf.add([shows[c, i] for c in code])         # every point shows an allowed pattern
    for c in code:
        if c:
            cnf.add([shows[c, i] for i in range(len(pts))])   # every codeword appears

    def decode(model):
        pos = {abs(x) for x in model if x > 0}
        val = lambda lit: lit == TRUE or (lit not in (TRUE, FALSE) and lit in pos)
        cert = {}
        for n in neurons:
            cert[str(n)] = {}
            for f in FORMS:
                a, b = RNG(K)[f]
                lo = next(t for t in range(a, b + 1) if val(L(n, f, t)))
                hi = next(t for t in range(a, b + 1) if val(H(n, f, t)))
                cert[str(n)][f] = [lo, hi]
        return cert

    return cnf, decode


def write_cnf(cnf, path):
    nv = max(abs(l) for c in cnf.clauses for l in c)
    with open(path, "w") as fh:
        fh.write(f"p cnf {nv} {len(cnf.clauses)}\n")
        for c in cnf.clauses:
            fh.write(" ".join(map(str, c)) + " 0\n")


def verify_proof(cnf_path, proof_path):
    """True only if drat-trim confirms the proof refutes the CNF."""
    out = subprocess.run([DRAT, cnf_path, proof_path], capture_output=True, text=True).stdout
    return "s VERIFIED" in out


CADICAL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tools", "cadical")


def decide_cadical(codewords, K, stem, timeout_s=None):
    """Same question, solved by the CaDiCaL program, which streams its proof to disk
    (so big grids don't run out of memory). Returns like decide()."""
    cnf, decode = build(codewords, K)
    write_cnf(cnf, stem + ".cnf")
    cmd = [CADICAL, "--no-binary", "-q", stem + ".cnf", stem + ".drat"]
    if timeout_s:
        cmd[1:1] = ["-t", str(int(timeout_s))]
    out = subprocess.run(cmd, capture_output=True, text=True).stdout
    if "s UNSATISFIABLE" in out:
        return "UNSAT", None, verify_proof(stem + ".cnf", stem + ".drat")
    if "s SATISFIABLE" in out:
        model = [int(x) for line in out.splitlines() if line.startswith("v ")
                 for x in line[2:].split() if x != "0"]
        return "SAT", decode(model), None
    return "UNKNOWN", None, None


def decide(codewords, K, stem=None):
    cnf, decode = build(codewords, K)
    with Glucose4(bootstrap_with=cnf.clauses, with_proof=True) as s:
        if s.solve():
            return "SAT", decode(s.get_model()), None
        proof = s.get_proof()
    stem = stem or f"/tmp/octsat_{os.getpid()}"
    write_cnf(cnf, stem + ".cnf")
    with open(stem + ".drup", "w") as fh:
        fh.write("\n".join(proof) + "\n")
    return "UNSAT", None, verify_proof(stem + ".cnf", stem + ".drup")


def main():
    path, K = sys.argv[1], int(sys.argv[2])
    codes = {c["id"]: c for c in json.load(open(path))["codes"]}
    os.makedirs("sat_results", exist_ok=True)
    for cid in sys.argv[3:]:
        c = codes[cid]
        t0 = time.time()
        stem = f"sat_results/{cid}_K{K}"
        if os.environ.get("ENGINE") == "cadical":
            r, cert, proof_ok = decide_cadical(c["codewords"], K, stem, float(os.environ.get("TLIM", 0)) or None)
        else:
            r, cert, proof_ok = decide(c["codewords"], K, stem)
        out = {"id": cid, "K": K, "result": r, "seconds": round(time.time() - t0, 1)}
        if r == "SAT":
            assert check(c["codewords"], cert)[0], f"{cid}: SAT drawing failed the referee"
            out["drawing"] = cert
        else:
            out["proof_verified_by_drat_trim"] = proof_ok
            for ext in (".drat", ".drup"):
                pf = stem + ext
                if os.path.exists(pf) and os.path.getsize(pf) > 0:
                    import hashlib
                    h = hashlib.sha256()
                    with open(pf, "rb") as fh:
                        for chunk in iter(lambda: fh.read(1 << 20), b""):
                            h.update(chunk)
                    out["proof_file"] = {"name": os.path.basename(pf), "bytes": os.path.getsize(pf),
                                         "sha256": h.hexdigest(),
                                         "rebuild": "tools/cadical --no-binary -q <id>_K<K>.cnf proof.drat"}
                if os.path.exists(pf) and not os.environ.get("KEEP_PROOF"):
                    os.remove(pf)          # big; rebuildable from the saved .cnf
        json.dump(out, open(stem + ".json", "w"), indent=1)
        print(cid, f"K={K}", r, "" if r == "SAT" else f"proof_verified={proof_ok}",
              f"({out['seconds']}s)", flush=True)


if __name__ == "__main__":
    main()
