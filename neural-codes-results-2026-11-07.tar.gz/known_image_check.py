"""
known_image_check.py - is any known NON-CONVEX code (one with NO local obstruction,
proven non-convex by hand in a paper) an image of my code?

Jeffs, Morphisms of Neural Codes, Thm 1.3: images of convex codes are convex.
So if a code maps onto a known non-convex code, the code is NOT convex.
Images = pick k distinct trunks; new neuron j fires iff the codeword is in trunk j.

Known non-convex codes (each has no local obstruction; checked below):
  LSW  Lienkaemper-Shiu-Woodstock 2017, Thm 3.1 (5 neurons)
  C0   Jeffs, Morphisms, Thm 5.10 (6 neurons)
  S2   Jeffs, Sunflowers of convex open sets, Thm 4.2 (6 neurons)
"""
import json, sys
from itertools import combinations, permutations
from neuralcodes import make_code, parse_short, has_local_obstruction
from morph_check import all_trunks, image

KNOWN = {
    "LSW": "2345 123 134 145 13 14 23 34 45 3 4",
    "C0": "3456 123 145 256 45 56 1 2 3",
    "S2": "13 23 4 5 6 234 135 1236 456",
}


def as_code(words):
    return set(parse_short(words.split())) | {frozenset()}


def canon(code, n):
    best = None
    for p in permutations(range(1, n + 1)):
        r = dict(zip(range(1, n + 1), p))
        v = tuple(sorted(tuple(sorted(r[i] for i in c)) for c in code))
        if best is None or v < best:
            best = v
    return best


def sig(code):
    return (len(code), tuple(sorted(len(c) for c in code)))


TARGETS = {}
for name, w in KNOWN.items():
    c = as_code(w)
    n = len(set().union(*c))
    TARGETS[name] = (n, sig(c), canon(c, n), c)


def find(code):
    """Returns (target name, trunk faces) or None."""
    trunks = all_trunks(code)
    tl = list(trunks)
    for name, (n, s, cn, _) in TARGETS.items():
        for combo in combinations(range(len(tl)), n):
            img = image(code, [tl[i] for i in combo])
            if sig(img) == s and canon(img, n) == cn:
                return name, [sorted(trunks[tl[i]]) for i in combo]
    return None


if __name__ == "__main__":
    for name, (n, s, cn, c) in TARGETS.items():
        print(name, "neurons", n, "local obstruction:", has_local_obstruction(c))
    codes = {c["id"]: c for c in json.load(open(sys.argv[1]))["codes"]}
    ids = sys.argv[2:] or sorted(codes)
    for cid in ids:
        r = find(make_code(codes[cid]["codewords"]))
        print(cid, r, flush=True)
