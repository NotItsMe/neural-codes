"""
poly.py - drawings in the plane where each neuron's region is an open convex polygon
whose edges point in a CHOSEN set of directions.

A direction is a pair (a, b) of whole numbers; a region is
        lo < a*x + b*y < hi      for every direction (a, b) in the set.
  2 directions  (1,0),(0,1)                       -> boxes
  4 directions  + (1,1),(1,-1)                    -> the octagons from before
  8 directions  + (1,2),(2,1),(1,-2),(2,-1)       -> up to 16-sided polygons

Three parts, same plan as the octagon tools:
1. REFEREE  check(code, cert, dirs): exact answer to "does this drawing make exactly
   this code?". Draw every edge line, cut the plane into vertical slabs at every place
   two lines cross, test one exact point (Fractions) in every vertex, edge piece and
   face. Nothing is skipped (same argument as oct_checker, for any directions).
2. GRID  grid_points(K, dirs): with whole-number limits and 0 <= x, y <= K, every possible
   edge line is a*x + b*y = k for a whole number k. Draw ALL of them; one test point per
   piece of that big picture is enough for every drawing at once. A piece is named by,
   for each direction, which line it sits on or which gap it sits in.
3. DECIDER  decide(code, K, dirs, stem): the finite yes/no question as true/false clauses.
   CaDiCaL solves it; a NO comes with a proof that drat-trim re-checks; a YES comes with
   a drawing that the referee re-checks.
"""
import math, os, subprocess
from fractions import Fraction as F
from itertools import combinations, count

DIRS2 = [(1, 0), (0, 1)]
DIRS3 = [(1, 0), (0, 1), (1, 1)]
DIRS4 = [(1, 0), (0, 1), (1, 1), (1, -1)]
DIRS8 = DIRS4 + [(1, 2), (2, 1), (1, -2), (2, -1)]
OCT_NAMES = {"x": (1, 0), "y": (0, 1), "x+y": (1, 1), "x-y": (1, -1)}

HERE = os.path.dirname(os.path.abspath(__file__))
CADICAL = os.path.join(HERE, "tools", "cadical")
DRAT = os.path.join(HERE, "tools", "drat-trim")


def key(d):
    return f"{d[0]},{d[1]}"


def val(d, p):
    return d[0] * p[0] + d[1] * p[1]


def oct_to_poly(regions):
    return {n: {key(OCT_NAMES[f]): r[f] for f in r} for n, r in regions.items()}


# ---------------- referee ----------------
def load(cert, dirs):
    names = {key(d): d for d in dirs}
    regions = {}
    for n, r in cert.items():
        reg = {}
        for k, (lo, hi) in r.items():
            assert k in names, f"neuron {n}: direction {k} is not in the allowed set"
            lo, hi = F(lo), F(hi)
            assert lo < hi, f"neuron {n}: empty range on {k}"
            reg[names[k]] = (lo, hi)
        regions[int(n)] = reg
    return regions


def inside(reg, p):
    return all(lo < val(d, p) < hi for d, (lo, hi) in reg.items())


def pattern_at(p, regions):
    return frozenset(n for n, reg in regions.items() if inside(reg, p))


def meet(l1, l2):
    (a1, b1), c1 = l1
    (a2, b2), c2 = l2
    det = a1 * b2 - a2 * b1
    if det == 0:
        return None
    return (F(c1 * b2 - c2 * b1) / det, F(a1 * c2 - a2 * c1) / det)


def sample_points(lines):
    """One exact point in every vertex, edge piece and face cut out by the lines (plus extras)."""
    lines = list(lines)
    vertical = [l for l in lines if l[0][1] == 0]
    slanted = [l for l in lines if l[0][1] != 0]
    xs = {F(c) / d[0] for d, c in vertical}
    for l1, l2 in combinations(lines, 2):
        p = meet(l1, l2)
        if p is not None:
            xs.add(p[0])
    xs = sorted(xs) or [F(0)]
    cols = [xs[0] - 1] + xs + [xs[-1] + 1] + [(xs[i] + xs[i + 1]) / 2 for i in range(len(xs) - 1)]
    pts = []
    for x in cols:
        ys = sorted({(F(c) - d[0] * x) / d[1] for d, c in slanted})
        if not ys:
            pts.append((x, F(0)))
            continue
        pts.append((x, ys[0] - 1))
        for i, y in enumerate(ys):
            pts.append((x, y))
            if i + 1 < len(ys):
                pts.append((x, (y + ys[i + 1]) / 2))
        pts.append((x, ys[-1] + 1))
    return pts


def produced_code(regions):
    lines = {(d, c) for reg in regions.values() for d, (lo, hi) in reg.items() for c in (lo, hi)}
    found = {}
    for p in sample_points(lines):
        found.setdefault(pattern_at(p, regions), p)
    return found


def check(target_codewords, cert, dirs):
    target = {frozenset(c) for c in target_codewords} | {frozenset()}
    regions = load(cert, dirs)
    assert set(regions) == set().union(*target), "need exactly one region per neuron"
    found = produced_code(regions)
    missing, extra = target - set(found), set(found) - target
    return (not missing and not extra), missing, extra, found


# ---------------- grid ----------------
def rng(d, K):
    v = [val(d, (x, y)) for x in (0, K) for y in (0, K)]
    return min(v), max(v)


def piece_name(p, dirs):
    """Which line / which gap the point is in, for every direction (2v if on a line, odd if between)."""
    out = []
    for d in dirs:
        v = val(d, p)
        out.append(2 * v.numerator if v.denominator == 1 else 2 * math.floor(v) + 1)
    return tuple(out)


_grid_cache = {}


def grid_points(K, dirs):
    """One test point per piece of the picture made by ALL lines a*x+b*y=k (whole k), inside
    the open box 0 < x, y < K (outside the box every region is off)."""
    ck = (K, tuple(dirs))
    if ck in _grid_cache:
        return _grid_cache[ck]
    assert (1, 0) in dirs and (0, 1) in dirs, "x and y limits keep every region inside the box"
    lines = [(d, k) for d in dirs for k in range(rng(d, K)[0], rng(d, K)[1] + 1)]
    seen = {}
    for p in sample_points(lines):
        if 0 < p[0] < K and 0 < p[1] < K:
            seen.setdefault(piece_name(p, dirs), p)
    _grid_cache[ck] = list(seen.values())
    return _grid_cache[ck]


# ---------------- decider (clauses + proof) ----------------
T, Fa = "T", "F"


def neg(l):
    return Fa if l == T else T if l == Fa else -l


def build(codewords, K, dirs, points=None):
    code = {frozenset(c) for c in codewords} | {frozenset()}
    neurons = sorted(set().union(*code))
    nv = count(1)
    clauses = []

    def add(lits):
        if T in lits:
            return
        lits = [l for l in lits if l != Fa]
        assert lits, "empty clause"
        clauses.append(lits)

    le = {}                                   # le[kind, n, d][t] = "limit <= t"
    for n in neurons:
        for d in dirs:
            a, b = rng(d, K)
            for kind in ("lo", "hi"):
                le[kind, n, d] = {t: next(nv) for t in range(a, b)}
                for t in range(a, b - 1):
                    add([-le[kind, n, d][t], le[kind, n, d][t + 1]])

    def LE(kind, n, d, t):
        a, b = rng(d, K)
        return Fa if t < a else T if t >= b else le[kind, n, d][t]

    for n in neurons:                         # lo < hi
        for d in dirs:
            a, b = rng(d, K)
            for t in range(a, b + 1):
                add([neg(LE("hi", n, d, t)), LE("lo", n, d, t - 1)])

    pts = points if points is not None else grid_points(K, dirs)
    inside_v = {}
    for i, p in enumerate(pts):
        for n in neurons:
            lits = []
            for d in dirs:
                v = val(d, p)
                lits += [LE("lo", n, d, math.ceil(v) - 1), neg(LE("hi", n, d, math.floor(v)))]
            if Fa in lits:
                inside_v[n, i] = Fa
                continue
            lits = [l for l in lits if l != T]
            if not lits:
                inside_v[n, i] = T
                continue
            b = next(nv)
            for l in lits:
                add([-b, l])
            add([b] + [neg(l) for l in lits])
            inside_v[n, i] = b
    shows = {}
    for i in range(len(pts)):
        row = []
        for c in code:
            need = [inside_v[n, i] if n in c else neg(inside_v[n, i]) for n in neurons]
            if Fa in need:
                continue                       # this pattern can never show here
            s = next(nv)
            for l in need:
                add([-s, l])
            shows[c, i] = s
            row.append(s)
        add(row)                               # every point shows an allowed pattern
    for c in code:
        if c:
            add([shows[c, i] for i in range(len(pts)) if (c, i) in shows])   # every codeword shows

    def decode(model):
        pos = {x for x in model if x > 0}
        tv = lambda l: l == T or (l != Fa and l in pos)
        cert = {}
        for n in neurons:
            cert[str(n)] = {}
            for d in dirs:
                a, b = rng(d, K)
                lo = next(t for t in range(a, b + 1) if tv(LE("lo", n, d, t)))
                hi = next(t for t in range(a, b + 1) if tv(LE("hi", n, d, t)))
                cert[str(n)][key(d)] = [lo, hi]
        return cert

    return clauses, decode, len(pts)


def write_cnf(clauses, path):
    nv = max(abs(l) for c in clauses for l in c)
    with open(path, "w") as fh:
        fh.write(f"p cnf {nv} {len(clauses)}\n")
        for c in clauses:
            fh.write(" ".join(map(str, c)) + " 0\n")


def verify_proof(cnf_path, proof_path):
    out = subprocess.run([DRAT, cnf_path, proof_path], capture_output=True, text=True).stdout
    return "s VERIFIED" in out


def decide(codewords, K, dirs, stem, timeout_s=None, keep_proof=False, proof=True):
    """Returns ("SAT", drawing, None) / ("UNSAT", None, proof_verified) / ("UNKNOWN", None, None)."""
    clauses, decode, _ = build(codewords, K, dirs)
    write_cnf(clauses, stem + ".cnf")
    cmd = [CADICAL, "--no-binary", "-q", stem + ".cnf"] + ([stem + ".drat"] if proof else [])
    if timeout_s:
        cmd[1:1] = ["-t", str(int(timeout_s))]
    out = subprocess.run(cmd, capture_output=True, text=True).stdout
    if "s UNSATISFIABLE" in out:
        ok = verify_proof(stem + ".cnf", stem + ".drat") if proof else None
        return "UNSAT", None, ok
    if os.path.exists(stem + ".drat") and not keep_proof:
        os.remove(stem + ".drat")
    if "s SATISFIABLE" in out:
        model = [int(x) for line in out.splitlines() if line.startswith("v ")
                 for x in line[2:].split() if x != "0"]
        return "SAT", decode(model), None
    return "UNKNOWN", None, None
