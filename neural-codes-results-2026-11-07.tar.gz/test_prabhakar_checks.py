"""Tests for prabhakar_checks.py. Run: python3 test_prabhakar_checks.py"""
import json, glob, os
from prabhakar_checks import split_cover, front_planar
def ok(n,c): print(("PASS  " if c else "FAIL  ")+n, flush=True); assert c, n
P=lambda s:[[int(ch) for ch in w] for w in s.split()]
Dmax=P("2 3 4 5 6 12 13 14 15 16 23 24 26 35 45 46 123 126 145 146 246 356 1246")
certs=split_cover(Dmax, find_all=True)
ok(f"Dmax has exactly 16 split-cover certificates, as the paper says (got {len(certs)})", len(certs)==16)
ok("all Dmax certificates have r=1, e=6, {a,b}={3,5}", all(c[0]==1 and c[3]==6 and {c[1],c[2]}=={3,5} for c in certs))
ok("paper's example certificate (1;3,5,6;{2,3}|{4,5,6};123,15) is found",
   (1,3,5,6,(2,3),(4,5,6),"123","15") in certs)
for w in ["1","124","56","36"]:   # witness codes: C24 + one face, convex per the paper
    C24=P("123 1246 145 356 12 14 3 5 6")
    ok(f"convex witness C24+{{{w}}} has no certificate", split_cover(C24+P(w)) is None)
# B0 (a=1 b=2 c=3 x=4 y=5 z=6): convex in R^3, NOT planar -> front_planar must fire
B0=P("1 2 3 12 13 23 14 25 36 123 1245 1346 2356")
ok("B0 (embedding dimension exactly 3) is flagged not planar", front_planar(B0) is not None)
codes={c['id']:c for c in json.load(open('jeffs_96_codes.json'))['codes']}
drawn2d={os.path.basename(f)[:6] for f in glob.glob('certificates/C5-*.json') if '_3D' not in f}
drawn3d={os.path.basename(f)[:6] for f in glob.glob('certificates/C5-*_3D.json')}
ok(f"no split-cover certificate on any of the {len(drawn2d|drawn3d)} drawn (convex) codes",
   not [c for c in drawn2d|drawn3d if split_cover(codes[c]['codewords'])])
ok(f"front_planar fires on none of the {len(drawn2d)} codes drawn in the plane",
   not [c for c in drawn2d if front_planar(codes[c]['codewords'])])
print("\nAll Prabhakar-check tests passed.")
