"""
prabhakar_checks.py - two more checks transcribed from Prabhakar (Yau Award 2026):

split_cover(code): Definition 7.2 / Theorem 7.3. A certificate (r; a,b,e; J|K; sigma, tau) => NOT convex.
  M = {j != r : Tk(rj) nonempty}
  SC0 {r} not a codeword. SC1 Tk(ae) nonempty and all contain b; Tk(be) nonempty and all contain a.
  SC2 Tk(abe) nonempty. SC3 M = J u K disjoint, a in J, b in K. SC4 sigma codeword, {r,a} in sigma,
  sigma & K empty. SC5 tau codeword, {r,b} in tau, tau & J empty. SC6 for all j in J, k in K, every
  codeword containing {r,j,k} contains e and omits a and b.

front_planar(code): Theorem 5.1 Step B, which on its own shows NO PLANAR realization (the paper uses it
  this way for B0). Faces x,y,z,a,b,c with
  F1 Tk(x)<=Tk(a), Tk(y)<=Tk(b), Tk(z)<=Tk(c)
  F2 Tk(ay)=Tk(xy)=Tk(bx), Tk(az)=Tk(xz)=Tk(cx), Tk(bz)=Tk(yz)=Tk(cy)
  F3 Tk(xyz) empty; Tk(xy), Tk(xz), Tk(yz) nonempty
  F4 Tk(abc) nonempty; Tk(abc+s) empty for s in x,y,z
"""
from itertools import combinations


def subsets(X):
    X = sorted(X)
    return [frozenset(c) for k in range(len(X) + 1) for c in combinations(X, k)]


def prep(codewords):
    code = sorted({frozenset(c) for c in codewords} | {frozenset()}, key=lambda w: (len(w), sorted(w)))
    memo = {}

    def Tk(X):
        X = frozenset(X)
        if X not in memo:
            memo[X] = frozenset(w for w in code if X <= w)
        return memo[X]
    return code, Tk


def split_cover(codewords, find_all=False):
    code, Tk = prep(codewords)
    n = sorted(set().union(*code))
    out = []
    for r in n:
        if frozenset({r}) in code:
            continue
        M = [j for j in n if j != r and Tk({r, j})]
        for a in M:
            for b in M:
                if a == b:
                    continue
                for e in n:
                    if e in (r, a, b):
                        continue
                    ae, be = Tk({a, e}), Tk({b, e})
                    if not ae or not be or any(b not in w for w in ae) or any(a not in w for w in be):
                        continue
                    if not Tk({a, b, e}):
                        continue
                    rest = [j for j in M if j not in (a, b)]
                    for k in range(len(rest) + 1):
                        for extra in combinations(rest, k):
                            J = {a} | set(extra)
                            K = set(M) - J
                            if b not in K:
                                continue
                            if not all(e in w and a not in w and b not in w
                                       for j in J for kk in K for w in Tk({r, j, kk})):
                                continue
                            sig = [w for w in code if {r, a} <= w and not (w & K)]
                            tau = [w for w in code if {r, b} <= w and not (w & J)]
                            for s in sig:
                                for t in tau:
                                    cert = (r, a, b, e, tuple(sorted(J)), tuple(sorted(K)),
                                            "".join(map(str, sorted(s))), "".join(map(str, sorted(t))))
                                    if not find_all:
                                        return cert
                                    out.append(cert)
    return out if find_all else None


def front_planar(codewords):
    code, Tk = prep(codewords)
    faces = sorted({f for w in code for f in subsets(w) if f}, key=lambda f: (len(f), sorted(f)))
    for x, y, z in combinations(faces, 3):
        xy, xz, yz = Tk(x | y), Tk(x | z), Tk(y | z)
        if Tk(x | y | z) or not xy or not xz or not yz:
            continue
        A = [f for f in faces if Tk(x) <= Tk(f) and Tk(f | y) == xy and Tk(f | z) == xz]
        B = [f for f in faces if Tk(y) <= Tk(f) and Tk(f | x) == xy and Tk(f | z) == yz]
        C = [f for f in faces if Tk(z) <= Tk(f) and Tk(f | x) == xz and Tk(f | y) == yz]
        for a in A:
            for b in B:
                for c in C:
                    abc = a | b | c
                    if Tk(abc) and not any(Tk(abc | s) for s in (x, y, z)):
                        s_ = lambda f: "".join(map(str, sorted(f)))
                        return dict(x=s_(x), y=s_(y), z=s_(z), a=s_(a), b=s_(b), c=s_(c))
    return None


if __name__ == "__main__":
    import json, sys
    codes = {c["id"]: c for c in json.load(open("jeffs_96_codes.json"))["codes"]}
    for cid in sys.argv[1:] or sorted(codes):
        cw = codes[cid]["codewords"]
        print(cid, "split_cover:", split_cover(cw), "| front_planar:", front_planar(cw), flush=True)
