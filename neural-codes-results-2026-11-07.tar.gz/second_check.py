"""
second_check.py - an independent second referee, using a different method from box_checker.py.

For every one of the 64 subsets S of neurons:
  start with the region inside every box in S (one box, still open),
  cut away each box NOT in S, keeping track of which edges are open or closed,
  and see whether anything survives. If something survives, pattern S appears.
Pieces are products of intervals stored as (low, low_closed, high, high_closed).
Run:  python3 second_check.py certificates/C5-004.json jeffs_96_codes.json
"""
import json, sys
from fractions import Fraction
from itertools import combinations


def nonempty(iv):
    lo, lc, hi, hc = iv
    return lo < hi or (lo == hi and lc and hc)


def subtract_interval(iv, cut):
    """Pieces of iv lying outside the OPEN interval cut=(c,d)."""
    lo, lc, hi, hc = iv
    c, d = cut
    out = [(lo, lc, min(hi, c), hc if hi <= c else True)]       # part at or left of c
    out.append((max(lo, d), lc if lo >= d else True, hi, hc))    # part at or right of d
    return [p for p in out if nonempty(p)]


def subtract_box(piece, box):
    """piece minus an open box: a point leaves the box by sitting outside it on some axis."""
    result = []
    prefix = list(piece)
    for k, cut in enumerate(box):
        for outside in subtract_interval(prefix[k], cut):
            result.append(tuple(prefix[:k] + [outside] + prefix[k + 1:]))
        # for later axes, stay INSIDE the box on axis k (so pieces don't overlap)
        lo, lc, hi, hc = prefix[k]
        c, d = cut
        inside = (max(lo, c), lc if lo > c else False, min(hi, d), hc if hi < d else False)
        if not nonempty(inside):
            break
        prefix[k] = inside
    return result


def patterns(boxes):
    neurons = sorted(boxes)
    dims = len(next(iter(boxes.values())))
    big = Fraction(10 ** 6)
    found = set()
    for r in range(len(neurons) + 1):
        for S in combinations(neurons, r):
            start = [(-big, True, big, True)] * dims
            for n in S:                       # intersect the boxes in S
                start = [(max(a[0], b[0]), False if b[0] >= a[0] else a[1],
                          min(a[2], b[1]), False if b[1] <= a[2] else a[3])
                         for a, b in zip(start, boxes[n])]
            if not all(nonempty(iv) for iv in start):
                continue
            pieces = [tuple(start)]
            for n in neurons:
                if n not in S:
                    pieces = [q for p in pieces for q in subtract_box(p, boxes[n])]
            if pieces:
                found.add(frozenset(S))
    return found


if __name__ == "__main__":
    cert = json.load(open(sys.argv[1]))
    codes = {c["id"]: c for c in json.load(open(sys.argv[2]))["codes"]}
    boxes = {int(n): [(Fraction(a), Fraction(b)) for a, b in box] for n, box in cert["boxes"].items()}
    target = {frozenset(w) for w in codes[cert["id"]]["codewords"]} | {frozenset()}
    got = patterns(boxes)
    print(cert["id"], "SECOND CHECK:", "PASS" if got == target else "FAIL",
          "| missing", sorted(map(sorted, target - got)), "| extra", sorted(map(sorted, got - target)))
