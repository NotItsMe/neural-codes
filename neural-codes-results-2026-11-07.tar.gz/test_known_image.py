"""Tests for known_image_check.py. Run: python3 test_known_image.py"""
from known_image_check import find, as_code, KNOWN
from neuralcodes import has_local_obstruction

def ok(name, cond):
    print(("PASS  " if cond else "FAIL  ") + name, flush=True)
    assert cond, name

for name, w in KNOWN.items():
    c = as_code(w)
    ok(f"{name} has no local obstruction (so it is a real 'hidden' example)", not has_local_obstruction(c))
    ok(f"{name} is caught (positive control)", find(c) is not None)

from known_image_check import TARGETS
ok("S2 is the same code as C0 up to relabelling (two papers, one code)", TARGETS["S2"][2] == TARGETS["C0"][2])

# Relabel C0 and add a harmless extra neuron 7 that always fires with 3: still must be found.
c0 = as_code(KNOWN["C0"])
r = {1: 4, 2: 6, 3: 1, 4: 2, 5: 3, 6: 5}
big = {frozenset(r[i] for i in c) | ({7} if 3 in c else set()) for c in c0}
ok("relabelled C0 with an extra neuron is still caught", find(big) is not None)

# The hollow triangle (convex) must not map onto any of them.
ok("convex hollow triangle is not flagged", find(as_code("12 13 23 1 2 3")) is None)
print("\nAll known-image tests passed.")
