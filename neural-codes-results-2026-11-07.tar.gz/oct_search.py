"""
oct_search.py - SEARCHER for octagon drawings in the plane (edges along x, y, x+y, x-y).
Every drawing it finds must pass oct_checker.check (referee) AND oct_second_check.check2
(independent Z3 referee) before it is saved.

Run:  python3 oct_search.py jeffs_96_codes.json SECONDS_PER_CODE [ids...]
Output: certificates/C5-xxx.json, oct_search_report.txt

How it works:
- Unknowns: for each neuron, a low and high limit on x, y, x+y and x-y (exact rationals).
- One witness point per codeword must show exactly that codeword.
- Two neurons that never fire together must be split apart along one of the four
  directions (two convex polygons that don't touch can always be split along a
  direction of one of their edges, and here every edge has one of four directions).
- Counterexample loop: if the referee finds a forbidden pattern at some point, add
  "that exact point must show an allowed pattern" and solve again.
- "NO_OCTAGON" means Z3 proved no such drawing exists with whole-number limits on
  [0,K]. It does NOT mean "not convex": finer grids, other shapes, or higher
  dimensions could still work.
"""
import json, os, sys, time
from itertools import combinations
from fractions import Fraction as F
from z3 import Int, Real, Solver, And, Or, Not, sat, unsat, RealVal

from oct_checker import check, FORMS
from oct_second_check import check2

B = 100


def fv(form, x, y):
    return {"x": x, "y": y, "x+y": x + y, "x-y": x - y}[form]


def rv(q):
    return RealVal(f"{q.numerator}/{q.denominator}")


def grid_points(K):
    """Fixed test spots for integer limits on [0,K]^2: in doubled coordinates (u,v)=(2x,2y)
    every edge line is u=even, v=even, u+v=even or u-v=even, so each 2x2 cell is cut into
    4 triangles meeting at its center. I take every corner, center, edge midpoint and
    triangle centroid, which touches every vertex, edge piece and face that can occur."""
    pts = set()
    for i in range(0, 2 * K, 2):
        for j in range(0, 2 * K, 2):
            c = [(i, j), (i + 2, j), (i + 2, j + 2), (i, j + 2)]
            m = (i + 1, j + 1)
            pts.add(m)
            for k in range(4):
                a, b = c[k], c[(k + 1) % 4]
                pts.add(a)
                pts.add(((a[0] + b[0]) / 2, (a[1] + b[1]) / 2))            # side midpoint
                pts.add(((a[0] + m[0]) / 2, (a[1] + m[1]) / 2))            # half-diagonal midpoint
                pts.add(((a[0] + b[0] + m[0]) / 3, (a[1] + b[1] + m[1]) / 3))  # triangle centroid
    return [(F(u) / 2 if not isinstance(u, float) else F(u).limit_denominator(12) / 2,
             F(v) / 2 if not isinstance(v, float) else F(v).limit_denominator(12) / 2) for u, v in pts]


def search(code, timeout_s, K=8):
    neurons = sorted(set().union(*code))
    faces = {frozenset(s) for c in code for k in range(len(c) + 1) for s in combinations(sorted(c), k)}
    rng = {"x": (0, K), "y": (0, K), "x+y": (0, 2 * K), "x-y": (-K, K)}
    lo = {(n, f): Int(f"lo_{n}_{f}") for n in neurons for f in FORMS}
    hi = {(n, f): Int(f"hi_{n}_{f}") for n in neurons for f in FORMS}
    s = Solver()
    for n in neurons:
        for f in FORMS:
            a, b = rng[f]
            s.add(a <= lo[n, f], lo[n, f] < hi[n, f], hi[n, f] <= b)

    def inside_r(n, x, y):        # x, y are Fractions or z3 reals
        return And([And(lo[n, f] < fv(f, x, y), fv(f, x, y) < hi[n, f]) for f in FORMS])

    def pattern_is(c, x, y):
        return And([inside_r(n, x, y) if n in c else Not(inside_r(n, x, y)) for n in neurons])

    for i, c in enumerate(c for c in code if c):
        wx, wy = Real(f"wx{i}"), Real(f"wy{i}")
        s.add(pattern_is(c, wx, wy))

    for a, b in combinations(neurons, 2):
        if frozenset({a, b}) not in faces:
            s.add(Or([Or(hi[a, f] <= lo[b, f], hi[b, f] <= lo[a, f]) for f in FORMS]))

    pts = grid_points(K)
    allowed = set(code)
    start, rounds = time.time(), 0
    while True:
        rounds += 1
        left = timeout_s - (time.time() - start)
        if left <= 0:
            return "TIMEOUT", None, rounds
        s.set("timeout", int(left * 1000))
        r = s.check()
        if r == unsat:
            return "NO_OCTAGON", None, rounds
        if r != sat:
            return "TIMEOUT", None, rounds
        m = s.model()
        L = {k: m[v].as_long() for k, v in lo.items()}
        H = {k: m[v].as_long() for k, v in hi.items()}
        bad = []
        for (x, y) in pts:
            pat = frozenset(n for n in neurons
                            if all(L[n, f] < {"x": x, "y": y, "x+y": x + y, "x-y": x - y}[f] < H[n, f] for f in FORMS))
            if pat not in allowed:
                bad.append((x, y))
        if not bad:
            cert = {str(n): {f: [L[n, f], H[n, f]] for f in FORMS} for n in neurons}
            if check(code, cert)[0]:
                return "SOLVED", cert, rounds
            raise RuntimeError("grid said OK but referee disagrees - investigate")
        for (x, y) in bad[:40]:
            s.add(Or([pattern_is(c, rv(x), rv(y)) for c in code]))


def main():
    path, t = sys.argv[1], float(sys.argv[2])
    only = set(sys.argv[3:])
    data = json.load(open(path))
    os.makedirs("certificates", exist_ok=True)
    lines = []
    for c in data["codes"]:
        cid = c["id"]
        if (only and cid not in only) or os.path.exists(f"certificates/{cid}.json"):
            continue
        code = [frozenset(w) for w in c["codewords"]] + [frozenset()]
        t0 = time.time()
        result, cert, rounds = search(code, t, K=int(os.environ.get("K", "6")))
        if result == "SOLVED":
            ok1 = check(c["codewords"], cert)[0]
            ok2 = check2(c["codewords"], cert)[0]
            assert ok1 and ok2, f"{cid}: checkers disagree, referee={ok1} second={ok2}"
            json.dump({"id": cid, "source_id": c["source_id"], "status": "CONVEX",
                       "shape": "octagon-2D (edges along x, y, x+y, x-y)", "regions": cert},
                      open(f"certificates/{cid}.json", "w"), indent=1)
        line = f"{cid} {result} ({rounds} rounds, {time.time()-t0:.1f}s)"
        print(line, flush=True)
        lines.append(line)
    with open("oct_search_report.txt", "a") as f:
        f.write(f"--- run with {t}s per code ---\n" + "\n".join(lines) + "\n")
    print("=== done ===", flush=True)


if __name__ == "__main__":
    main()
