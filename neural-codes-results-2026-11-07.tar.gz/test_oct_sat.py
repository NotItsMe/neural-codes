"""Tests for the SAT + proof-file octagon decider. Run: python3 test_oct_sat.py"""
import json, os
from oct_sat import decide, build, write_cnf, verify_proof
from oct_checker import check

def ok(name, cond):
    print(("PASS  " if cond else "FAIL  ") + name, flush=True)
    assert cond, name

codes = {c["id"]: c for c in json.load(open("jeffs_96_codes.json"))["codes"]}
w = lambda cid: codes[cid]["codewords"]
tmp = "/tmp/test_octsat"

tri = [[1], [2], [3], [1, 2], [1, 3], [2, 3]]
r, cert, _ = decide(tri, 3, tmp + "_tri")
ok("hollow triangle is drawable (referee-checked)", r == "SAT" and check(tri, cert)[0])

dis = [[1, 2], [2, 3], [1], [3]]
r, _, proof_ok = decide(dis, 4, tmp + "_dis")
ok("{12,23,1,3} has no drawing", r == "UNSAT")
ok("...and drat-trim verifies the proof", proof_ok is True)

# A proof must NOT verify against a different, satisfiable formula.
cnf, _ = build(tri, 4)
write_cnf(cnf, tmp + "_tri4.cnf")
ok("a proof for one formula is rejected on another", not verify_proof(tmp + "_tri4.cnf", tmp + "_dis.drup"))

for cid in ["C5-002", "C5-022"]:
    r, cert, _ = decide(w(cid), 6, tmp + cid)
    ok(f"{cid} (drawn earlier on 0..6) is YES, referee-checked", r == "SAT" and check(w(cid), cert)[0])

r, _, proof_ok = decide(w("C5-068"), 6, tmp + "_068")
ok("C5-068 is NO on 0..6 (agrees with Z3, twice)", r == "UNSAT")
ok("...and drat-trim verifies the C5-068 proof", proof_ok is True)

print("\nAll SAT-decider tests passed.")

# CaDiCaL engine must agree with the in-memory engine.
from oct_sat import decide_cadical
r, cert, _ = decide_cadical(tri, 3, tmp + "_ctri")
ok("[cadical] hollow triangle YES, referee-checked", r == "SAT" and check(tri, cert)[0])
r, _, pv = decide_cadical(dis, 4, tmp + "_cdis")
ok("[cadical] {12,23,1,3} NO with verified proof", r == "UNSAT" and pv is True)
r, cert, _ = decide_cadical(w("C5-002"), 6, tmp + "_c002")
ok("[cadical] C5-002 YES, referee-checked", r == "SAT" and check(w("C5-002"), cert)[0])
r, _, pv = decide_cadical(w("C5-068"), 6, tmp + "_c068")
ok("[cadical] C5-068 NO with verified proof", r == "UNSAT" and pv is True)
print("\nCaDiCaL engine tests passed.")
