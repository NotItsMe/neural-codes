"""
box_search.py - the SEARCHER. Tries to draw each code with open boxes using Z3.
Every drawing it finds is judged by box_checker.check() (the referee) before it counts.

Run:  python3 box_search.py jeffs_96_codes.json
Output: certificates/C5-xxx.json for each solved code, and box_search_report.txt

How it works (different method from the referee on purpose):
- Sorting the 12 box edges on an axis is all that matters, so every edge can sit on an
  EVEN number 0..22 without losing any drawing. Then the odd numbers are the gaps
  between edges, and the integers -1..23 are every place a pattern could appear.
- Z3 must place one witness point for every codeword, and must keep the boxes of every
  "non-face" (neurons that never fire together) apart on some axis.
- If the referee still finds a leaked pattern at some grid point, I add
  "this grid point must show an allowed pattern" and ask Z3 again (a counterexample loop).
- If Z3 answers "impossible", no box drawing exists in that dimension at all.
"""
import json, os, sys, time
from itertools import combinations
from z3 import Int, Solver, And, Or, Not, sat, unsat
from box_checker import check

TOP = 22                      # edges live on even numbers 0..22
GRID = range(-1, TOP + 2)     # every grid coordinate a pattern can live at


def minimal_nonfaces(code, n=6):
    faces = {frozenset(s) for c in code for k in range(len(c) + 1) for s in combinations(c, k)}
    out = []
    for k in range(2, n + 1):
        for s in combinations(range(1, n + 1), k):
            s = frozenset(s)
            if s not in faces and all(s - {x} in faces for x in s):
                out.append(s)
    return out


def search(code, dim, timeout_s):
    neurons = sorted(set().union(*code))
    lo = {(i, k): Int(f"lo_{i}_{k}") for i in neurons for k in range(dim)}
    hi = {(i, k): Int(f"hi_{i}_{k}") for i in neurons for k in range(dim)}
    s = Solver()
    s.set("timeout", int(timeout_s * 1000))

    for i in neurons:
        for k in range(dim):
            s.add(lo[i, k] % 2 == 0, hi[i, k] % 2 == 0,
                  0 <= lo[i, k], lo[i, k] < hi[i, k], hi[i, k] <= TOP)

    def inside(i, pt):        # pt may hold numbers or Z3 variables
        return And([And(lo[i, k] < pt[k], pt[k] < hi[i, k]) for k in range(dim)])

    def pattern_is(c, pt):
        return And([inside(i, pt) if i in c else Not(inside(i, pt)) for i in neurons])

    # one witness point per nonempty codeword
    for idx, c in enumerate(c for c in code if c):
        w = [Int(f"w_{idx}_{k}") for k in range(dim)]
        for v in w:
            s.add(-1 <= v, v <= TOP + 1)
        s.add(pattern_is(c, w))

    # neurons that never fire together: their boxes must miss each other on some axis
    for sig in minimal_nonfaces(code):
        s.add(Or([hi[i, k] <= lo[j, k] for k in range(dim) for i in sig for j in sig if i != j]))

    allowed = list(code)
    rounds = 0
    start = time.time()
    while True:
        rounds += 1
        left = timeout_s - (time.time() - start)
        if left <= 0:
            return "TIMEOUT", None, rounds
        s.set("timeout", int(left * 1000))
        r = s.check()
        if r == unsat:
            return "NO_BOX_DRAWING", None, rounds
        if r != sat:
            return "TIMEOUT", None, rounds
        m = s.model()
        cert = {str(i): [[m[lo[i, k]].as_long(), m[hi[i, k]].as_long()] for k in range(dim)]
                for i in neurons}
        ok, missing, extra, found = check(code, cert)
        if ok:
            return "SOLVED", cert, rounds
        # block every leak at the exact grid point where the referee saw it
        for pattern in extra:
            pt = [int(x) for x in found[pattern]]
            pt = [max(-1, min(TOP + 1, x)) for x in pt]
            s.add(Or([pattern_is(c, pt) for c in allowed]))


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "jeffs_96_codes.json"
    waves = [(1, 10), (2, 30), (3, 60)]           # (dimension, seconds per code)
    data = json.load(open(path))
    os.makedirs("certificates", exist_ok=True)
    status = {c["id"]: "UNKNOWN" for c in data["codes"]}
    notes = {c["id"]: [] for c in data["codes"]}

    for dim, t in waves:
        for c in data["codes"]:
            cid = c["id"]
            if status[cid] == "SOLVED":
                continue
            code = [frozenset(w) for w in c["codewords"]]
            t0 = time.time()
            result, cert, rounds = search(code, dim, t)
            notes[cid].append(f"{dim}D:{result}({rounds} rounds,{time.time()-t0:.1f}s)")
            if result == "SOLVED":
                ok = check(c["codewords"], cert)[0]        # judge it once more, fresh
                assert ok, f"{cid} certificate failed the referee"
                status[cid] = "SOLVED"
                json.dump({"id": cid, "source_id": c["source_id"], "status": "CONVEX",
                           "dimension": dim, "boxes": cert},
                          open(f"certificates/{cid}.json", "w"), indent=1)
            print(cid, notes[cid][-1], flush=True)
        n = sum(v == "SOLVED" for v in status.values())
        print(f"=== after {dim}D: {n} of 96 solved ===", flush=True)

    with open("box_search_report.txt", "w") as f:
        f.write(f"Box search on {path}\nSOLVED = referee-verified box drawing (certificates/)\n"
                "NO_BOX_DRAWING = Z3 proved no box drawing exists in that dimension\n\n")
        for cid in status:
            f.write(f"{cid}  {status[cid]:8s}  {'  '.join(notes[cid])}\n")
        f.write(f"\nTOTAL SOLVED: {sum(v == 'SOLVED' for v in status.values())} of 96\n")


if __name__ == "__main__":
    main()
