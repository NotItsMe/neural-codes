"""
poly3d.py - drawings in ANY dimension (built for 3D): each neuron's region is an open convex
polytope   lo < a.p < hi   for every direction a in a chosen set (whole-number limits).

Why 3D: Jeffs' code T3 = {135,246,12,34,56,1,..,6} is in my exact family (6 neurons,
5 maximal, minimal, no local obstruction) and is convex in R^3 but NOT in the plane.
So some of my 36 open codes may only be drawable in 3D.

1. REFEREE  check(code, cert, dirs): exact. For every set S of neurons, Z3 (exact rational
   arithmetic) answers "is there a point inside exactly the regions in S?". That gives the
   full code the drawing makes; compare with the target. Works in any dimension.
2. SEARCH   search(code, dirs, K, timeout): unknown whole-number limits on [0,K]-ish ranges.
   Each codeword gets its own witness point that must show exactly that codeword. Then a
   counterexample loop: ask the referee; if some point shows a forbidden pattern, add
   "that exact point must show an allowed pattern" and solve again. A YES is always
   referee-checked; a timeout proves nothing.
"""
import json, os, sys, time
from fractions import Fraction as F
from itertools import combinations
from z3 import Int, Real, Solver, And, Or, Not, Sum, sat, unsat, RealVal, Q

AX3 = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
DIAG3 = AX3 + [(1, 1, 0), (1, -1, 0), (1, 0, 1), (1, 0, -1), (0, 1, 1), (0, 1, -1)]


def key(d):
    return ",".join(map(str, d))


def dot(d, p):
    return sum(a * x for a, x in zip(d, p))


def rv(q):
    return Q(q.numerator, q.denominator)


# ---------------- referee ----------------
def load(cert, dirs):
    names = {key(d): d for d in dirs}
    out = {}
    for n, r in cert.items():
        out[int(n)] = {}
        for k, (lo, hi) in r.items():
            assert k in names, f"neuron {n}: direction {k} not allowed"
            assert F(lo) < F(hi), f"neuron {n}: empty range on {k}"
            out[int(n)][names[k]] = (F(lo), F(hi))
    return out


def produced_code(regions, dim):
    """Every pattern the drawing makes, each with an exact witness point."""
    neurons = sorted(regions)
    p = [Real(f"p{i}") for i in range(dim)]

    def ins(n):
        return And([And(rv(lo) < dot(d, p), dot(d, p) < rv(hi)) for d, (lo, hi) in regions[n].items()])

    found = {}
    for k in range(len(neurons) + 1):
        for S in combinations(neurons, k):
            s = Solver()
            s.add([ins(n) if n in S else Not(ins(n)) for n in neurons])
            if s.check() == sat:
                m = s.model()
                found[frozenset(S)] = tuple(F(str(m.eval(x, model_completion=True).as_fraction())) for x in p)
    return found


def check(target_codewords, cert, dirs):
    target = {frozenset(c) for c in target_codewords} | {frozenset()}
    regions = load(cert, dirs)
    assert set(regions) == set().union(*target), "need exactly one region per neuron"
    found = produced_code(regions, len(dirs[0]))
    missing, extra = target - set(found), set(found) - target
    return (not missing and not extra), missing, extra, found


# ---------------- search ----------------
def rng(d, K):
    lo = sum(min(0, a * K) for a in d)
    hi = sum(max(0, a * K) for a in d)
    return lo, hi


def search(codewords, dirs, K, timeout_s):
    code = {frozenset(c) for c in codewords} | {frozenset()}
    neurons = sorted(set().union(*code))
    dim = len(dirs[0])
    lo = {(n, d): Int(f"lo_{n}_{key(d)}") for n in neurons for d in dirs}
    hi = {(n, d): Int(f"hi_{n}_{key(d)}") for n in neurons for d in dirs}
    s = Solver()
    for n in neurons:
        for d in dirs:
            a, b = rng(d, K)
            s.add(a <= lo[n, d], lo[n, d] < hi[n, d], hi[n, d] <= b)

    def ins(n, p):
        return And([And(lo[n, d] < dot(d, p), dot(d, p) < hi[n, d]) for d in dirs])

    def shows(c, p):
        return And([ins(n, p) if n in c else Not(ins(n, p)) for n in neurons])

    for i, c in enumerate(c for c in code if c):
        s.add(shows(c, [Real(f"w{i}_{j}") for j in range(dim)]))
    faces = {frozenset(x) for c in code for k in range(len(c) + 1) for x in combinations(sorted(c), k)}
    for a, b in combinations(neurons, 2):          # helpful, not needed for soundness
        if frozenset({a, b}) not in faces:
            s.add(Or([Or(hi[a, d] <= lo[b, d], hi[b, d] <= lo[a, d]) for d in dirs]))

    start, rounds = time.time(), 0
    while True:
        rounds += 1
        left = timeout_s - (time.time() - start)
        if left <= 0:
            return "TIMEOUT", None, rounds
        s.set("timeout", int(left * 1000))
        r = s.check()
        if r == unsat:
            return "NONE_ON_GRID", None, rounds      # no drawing with these limits
        if r != sat:
            return "TIMEOUT", None, rounds
        m = s.model()
        cert = {str(n): {key(d): [m[lo[n, d]].as_long(), m[hi[n, d]].as_long()] for d in dirs} for n in neurons}
        ok, missing, extra, found = check(codewords, cert, dirs)
        if ok:
            return "SOLVED", cert, rounds
        assert not missing, "witness points guarantee every codeword shows"
        for pat in extra:
            pt = [rv(x) for x in found[pat]]
            s.add(Or([shows(c, pt) for c in code]))


def main():
    path, K, t = sys.argv[1], int(sys.argv[2]), float(sys.argv[3])
    codes = {c["id"]: c for c in json.load(open(path))["codes"]}
    os.makedirs("poly3d_results", exist_ok=True)
    for cid in sys.argv[4:]:
        out_path = f"poly3d_results/{cid}_K{K}.json"
        if os.path.exists(out_path) and json.load(open(out_path))["result"] == "SOLVED":
            continue
        t0 = time.time()
        r, cert, rounds = search(codes[cid]["codewords"], DIAG3, K, t)
        out = {"id": cid, "directions": [list(d) for d in DIAG3], "K": K, "result": r,
               "rounds": rounds, "seconds": round(time.time() - t0, 1)}
        if cert:
            assert check(codes[cid]["codewords"], cert, DIAG3)[0]
            out["drawing"] = cert
        json.dump(out, open(out_path, "w"), indent=1)
        print(cid, r, rounds, "rounds", out["seconds"], "s", flush=True)


if __name__ == "__main__":
    main()
