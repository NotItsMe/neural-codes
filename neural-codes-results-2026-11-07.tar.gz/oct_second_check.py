"""
oct_second_check.py - independent second referee for octagon drawings.
Different method from oct_checker.py: for each of the 64 neuron subsets S, ask the Z3
solver (exact rational arithmetic) "is there a point inside every region in S and
outside every other region?" The set of S that answer yes is the drawing's code.
"""
from itertools import combinations
from fractions import Fraction as F
from z3 import Real, Solver, And, Or, sat, RealVal

from oct_checker import load


def z3_value(form, x, y):
    return {"x": x, "y": y, "x+y": x + y, "x-y": x - y}[form]


def produced_code_z3(regions):
    x, y = Real("x"), Real("y")
    rv = lambda q: RealVal(f"{q.numerator}/{q.denominator}")
    def inside(reg):
        return And([And(rv(lo) < z3_value(f, x, y), z3_value(f, x, y) < rv(hi)) for f, (lo, hi) in reg.items()])
    def outside(reg):
        return Or([Or(z3_value(f, x, y) <= rv(lo), z3_value(f, x, y) >= rv(hi)) for f, (lo, hi) in reg.items()])
    ns = sorted(regions)
    found = set()
    for r in range(len(ns) + 1):
        for S in combinations(ns, r):
            s = Solver()
            for n in ns:
                s.add(inside(regions[n]) if n in S else outside(regions[n]))
            if s.check() == sat:
                found.add(frozenset(S))
    return found


def check2(target_codewords, cert):
    target = {frozenset(c) for c in target_codewords} | {frozenset()}
    got = produced_code_z3(load(cert))
    return got == target, target - got, got - target
