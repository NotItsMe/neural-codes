"""
absorption.py - independent re-implementation of the absorption criterion (Prabhakar, "Counterexamples
to Jeffs' Conjecture on Convex Neural Codes", Yau Award 2026, Lemma 4.1 + Lemma 8.1).

Walk a straight segment from a point of codeword s to a point of codeword t. Erase loops, so the
codewords met form a simple sequence v0=s, ..., vk=t. In a convex realization it must satisfy:
  (1) consecutive codewords are comparable (one contains the other);
  (2) vi & vj is inside vm whenever i < m < j          (each U meets the segment in an interval);
  (3) absorption: if a in vi, b in vj, mu inside vm, i <= m <= j, and Tk(mu+a) = Tk(mu+b) nonempty,
      then a and b are both in vm.   [Tk(X) = set of codewords containing X]
If for some pair (s, t) NO such sequence exists, the code is not convex.
"""
from itertools import combinations


def subsets(X):
    X = sorted(X)
    return [frozenset(c) for k in range(len(X) + 1) for c in combinations(X, k)]


class Absorb:
    def __init__(self, codewords):
        self.code = sorted({frozenset(c) for c in codewords} | {frozenset()}, key=lambda w: (len(w), sorted(w)))
        self.neurons = sorted(set().union(*self.code))
        self.tk, self.pairs, self.memo = {}, {}, {}
        self.nbrs = {v: [w for w in self.code if w < v or v < w] for v in self.code}

    def Tk(self, X):
        if X not in self.tk:
            self.tk[X] = frozenset(w for w in self.code if X <= w)
        return self.tk[X]

    def P(self, mu):
        if mu not in self.pairs:
            self.pairs[mu] = [(a, b) for a in self.neurons for b in self.neurons
                              if self.Tk(mu | {a}) and self.Tk(mu | {a}) == self.Tk(mu | {b})]
        return self.pairs[mu]

    def r3(self, vi, vm, vj):
        k = (vi, vm, vj)
        if k not in self.memo:
            self.memo[k] = any(a in vi and b in vj and not (a in vm and b in vm)
                               for mu in subsets(vm) for a, b in self.P(mu))
        return self.memo[k]

    def ok(self, seq, w):
        """can w be appended to seq? checks every triple whose last position is the new one."""
        full = seq + [w]
        j = len(seq)
        for i in range(j + 1):
            vi = full[i]
            for m in range(i, j + 1):
                vm = full[m]
                if i < m < j and not (vi & w) <= vm:
                    return False
                if self.r3(vi, vm, w):
                    return False
        return True

    def has_sequence(self, s, t):
        if not self.ok([], s):
            return False

        def dfs(seq):
            if seq[-1] == t:
                return True
            for w in self.nbrs[seq[-1]]:
                if w not in seq and self.ok(seq, w) and dfs(seq + [w]):
                    return True
            return False

        return dfs([s])

    def flagged(self):
        """(s, t) with no valid sequence (=> NOT convex), or None."""
        for s, t in combinations(self.code, 2):
            if not self.has_sequence(s, t):
                return sorted(s), sorted(t)
        return None


def flagged(codewords):
    return Absorb(codewords).flagged()


if __name__ == "__main__":
    import json, sys
    codes = {c["id"]: c for c in json.load(open("jeffs_96_codes.json"))["codes"]}
    for cid in sys.argv[1:] or sorted(codes):
        print(cid, codes[cid]["source_id"], flagged(codes[cid]["codewords"]), flush=True)
