# What the literature says (my synthesis, 2026-11-07)

## Known ways to prove a code NON-convex (open sets)
| Method | Source | Proof type | Checked on my 96 |
|---|---|---|---|
| Local obstruction (link not contractible) | Curto et al. 2017; Giusti-Itskov | topology, automatic | none (homology + exact) |
| Second-kind obstruction (link not collapsible) | Chen-Frick-Shiu 2019 | topology, automatic | none (exact collapse, 1741 links) |
| Wheels / sprockets / wire wheels | Ruys de Perez-Matusevich-Shiu 2023 | segment/order argument packaged as a rule | none (authors' own screen) |
| Morphism image has a local obstruction | Jeffs 2020 Thm 1.3 | automatic | none (homology) |
| Morphism image = known hidden non-convex code (LSW, C0=S2) | Jeffs 2020; LSW 2017; Jeffs sunflowers | automatic transfer of a hand proof | none (known_image_check.py, 9 tests) |
| Order-forcing + case contradiction | Jeffs-Lienkaemper-Youngs 2020 | hand proof per code, no general algorithm | not run |
| Sunflower theorem | Jeffs (arXiv:1810.03741) | hand proof; only 6-neuron example has 4 maximal | n/a |

Notes:
- Every code proven non-convex WITHOUT a local obstruction was done by a short hand argument:
  pick witness points, draw a segment (convexity: it stays inside common regions), use a Helly-type
  lemma (three convex sets with equal pairwise intersections: a line meeting all three meets the
  common part) to force the segment through a forbidden pattern. Not brute force.
- S2 (sunflower paper) and C0 (morphisms paper) are the same code up to relabelling.
- Jeffs' T3 = {135,246,12,34,56,1,...,6} has 6 neurons, 5 maximal, no local obstruction, minimal,
  is convex but NOT drawable in the plane (needs R^3). Not one of my 96. So "fails every 2D test"
  is weak evidence of non-convexity in this family.
- No 2024-2026 paper found with a new open-convexity obstruction (search not exhaustive).

Source notes (not included): 01_lsw_nonlocal.md, 02_sunflowers.md, 03_order_forcing.md, 04_wheels_recent.md,
05_morphisms_decidability.md, 06_classifications.md. Codewords there came via summaries; the
three test codes used in code were checked to have no local obstruction.
