"""Tests for poly.py: drawings whose edges can point in ANY chosen set of directions.
Run: python3 test_poly.py"""
import json, glob, copy
from fractions import Fraction as F
import oct_checker
from poly import DIRS4, DIRS8, check, oct_to_poly, grid_points, decide

def ok(name, cond):
    print(("PASS  " if cond else "FAIL  ") + name, flush=True)
    assert cond, name

codes = {c["id"]: c for c in json.load(open("jeffs_96_codes.json"))["codes"]}
w = lambda cid: codes[cid]["codewords"]

# 1. With the 4 octagon directions, the new referee must agree with the old one on all 57 drawings.
certs = sorted(glob.glob("certificates/C5-*.json"))
agree = 0
for path in certs:
    cid = path.split("/")[-1][:-5]
    cert = json.load(open(path))
    if "regions" not in cert or "x+y" not in json.dumps(cert):
        continue                                   # the box drawing (C5-004) uses another format
    pc = oct_to_poly(cert["regions"])
    agree += check(w(cid), pc, DIRS4)[0] and oct_checker.check(w(cid), cert["regions"])[0]
ok(f"new referee agrees with octagon referee on all 57 octagon drawings ({agree})", agree == 57)

# 2. It must catch a broken drawing: shrink one region of a good drawing until something changes.
cert = oct_to_poly(json.load(open("certificates/C5-002.json"))["regions"])
bad = copy.deepcopy(cert)
n = sorted(bad)[0]
d = sorted(bad[n])[0]
bad[n][d] = [bad[n][d][0], bad[n][d][0] + F(1, 1000)]
ok("referee rejects a broken drawing", not check(w("C5-002"), bad, DIRS4)[0])

# 3. A slanted direction that octagons do not have: the region 0 < x+2y < 3 inside the box
#    must be seen exactly (a point just inside and just outside its edge).
from poly import inside, load
reg = load({"1": {"1,0": [0, 4], "0,1": [0, 4], "1,2": [0, 3]}}, DIRS8)[1]
ok("x+2y edge: (1, 0.99) inside, (1, 1.01) outside", inside(reg, (F(1), F(99, 100))) and not inside(reg, (F(1), F(101, 100))))

# 4. The fixed grid must see EVERY piece of any whole-number drawing on 0..K:
#    the set of patterns at grid points has to equal what the exact referee finds.
from poly import pattern_at, produced_code
def grid_sees_all(cert, K, dirs):
    regs = load(cert, dirs)
    at_grid = {pattern_at(p, regs) for p in grid_points(K, dirs)} | {frozenset()}
    return at_grid == set(produced_code(regs))
small = []
for path in certs:
    reg = json.load(open(path)).get("regions", {})
    vals = [v for r in reg.values() for f in ("x", "y") for v in r.get(f, [])]
    if "x+y" in json.dumps(reg) and vals and min(vals) >= 0 and max(vals) <= 6:
        small.append(oct_to_poly(reg))
ok(f"4-direction grid on 0..6 sees every piece of {len(small)} real drawings",
   len(small) > 20 and all(grid_sees_all(c, 6, DIRS4) for c in small))
slanted = {"1": {"1,0": [0, 4], "0,1": [0, 4], "1,2": [1, 7]},
           "2": {"2,1": [3, 9], "1,-2": [-5, 1], "0,1": [1, 3]},
           "3": {"2,-1": [-2, 4], "1,1": [2, 5]}}
ok("8-direction grid on 0..4 sees every piece of a slanted drawing", grid_sees_all(slanted, 4, DIRS8))

# 5. Exact decider, 4 directions, must reproduce known answers.
tri = [[1], [2], [3], [1, 2], [1, 3], [2, 3]]
r, cert, _ = decide(tri, 3, DIRS4, "/tmp/tp_tri")
ok("hollow triangle YES with 4 directions, referee-checked", r == "SAT" and check(tri, cert, DIRS4)[0])
r, _, pv = decide([[1, 2], [2, 3], [1], [3]], 3, DIRS8, "/tmp/tp_dis")
ok("{12,23,1,3} NO with 8 directions, proof verified", r == "UNSAT" and pv is True)
r, cert, _ = decide(w("C5-002"), 6, DIRS4, "/tmp/tp_002")
ok("C5-002 YES on 0..6 with 4 directions", r == "SAT" and check(w("C5-002"), cert, DIRS4)[0])
r, _, pv = decide(w("C5-068"), 6, DIRS4, "/tmp/tp_068")
ok("C5-068 NO on 0..6 with 4 directions (matches octagon result), proof verified", r == "UNSAT" and pv is True)

# 6. With 3 directions only (x, y, x+y) a hollow triangle still works; with 2 (boxes) it must fail.
from poly import DIRS3
r, _, _ = decide(tri, 3, DIRS3, "/tmp/tp_tri3")
ok("hollow triangle YES with 3 directions", r == "SAT")
r, _, pv = decide(tri, 4, [(1, 0), (0, 1)], "/tmp/tp_tri2")
ok("hollow triangle NO with boxes only (Helly), proof verified", r == "UNSAT" and pv is True)

print("\nAll poly tests passed.")
