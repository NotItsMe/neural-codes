"""Tests for absorption.py (independent reproduction of Prabhakar 2026, Lemma 8.1). Run: python3 test_absorption.py"""
import json
from absorption import flagged
def ok(n,c): print(("PASS  " if c else "FAIL  ")+n, flush=True); assert c, n
P=lambda s:[[int(c) for c in w] for w in s.split()]
ok("LSW (known non-convex, no local obstruction) is flagged", flagged(P('2345 123 134 145 13 14 23 34 45 3 4')) is not None)
ok("C0 (known non-convex) is flagged", flagged(P('3456 123 145 256 45 56 1 2 3')) is not None)
ok("T3 (convex in R^3) is not flagged", flagged(P('135 246 12 34 56 1 2 3 4 5 6')) is None)
codes={c['id']:c for c in json.load(open('jeffs_96_codes.json'))['codes']}
import glob,os
convex={os.path.basename(f).split('_')[0].split('.')[0] for f in glob.glob('certificates/C5-*.json')}
hits=[c for c in sorted(convex) if flagged(codes[c]['codewords'])]
ok(f"none of the {len(convex)} codes I drew is flagged", not hits)
got={c for c in codes if c not in convex and flagged(codes[c]['codewords'])}
ok(f"open codes flagged = exactly the paper's FiveFac499/505/511 (got {sorted(got)})",
   {codes[c]['source_id'] for c in got}=={'FiveFac499','FiveFac505','FiveFac511'})
print("\nAll absorption tests passed.")
