"""verify3d.py C5-xxx : exact referee + independent (1/6)-grid scan of a saved 3D drawing; saves certificate."""
import json, sys, shutil
from fractions import Fraction as F
from itertools import product
from poly3d import check, load, DIAG3, dot
codes={c['id']:c for c in json.load(open('jeffs_96_codes.json'))['codes']}
for cid in sys.argv[1:]:
    r=json.load(open(f'poly3d_results/{cid}_K{r_K}.json')) if False else json.load(open(f'poly3d_results/{cid}_K4.json'))
    cw=codes[cid]['codewords']
    ok=check(cw,r['drawing'],DIAG3)[0]
    reg=load(r['drawing'],DIAG3); target={frozenset(c) for c in cw}|{frozenset()}
    seen={frozenset(n for n,rg in reg.items() if all(lo<dot(d,p)<hi for d,(lo,hi) in rg.items()))
          for p in product([F(i,6) for i in range(-3,28)],repeat=3)}
    bad=seen-target
    print(cid,'exact referee',ok,'| grid: forbidden',len(bad),'unhit codewords',len(target-seen))
    if ok and not bad: shutil.copy(f'poly3d_results/{cid}_K4.json',f'certificates/{cid}_3D.json')
