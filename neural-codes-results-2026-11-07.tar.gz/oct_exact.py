"""
oct_exact.py - EXACT yes/no for "can this code be drawn with octagons whose limits are
whole numbers on 0..K?"  (octagon = open region lo < x, y, x+y, x-y < hi)

Why a finite check is enough: with whole-number limits, every edge line is x=k, y=k,
x+y=k or x-y=k. These cut each unit square into 4 triangles. Every vertex, edge piece
and face of that grid contains one of these test points: square corners, square
centers, side midpoints, half-diagonal midpoints, triangle centroids (oct_search.grid_points).
And on each such piece, every neuron is either fully in or fully out. So:
    drawing is correct  <=>  every test point shows an allowed pattern
                             AND every codeword shows up at some test point.
That is a finite question over whole-number unknowns. No timeouts in the logic:
"UNSAT" means NO such drawing exists, full stop (for this K).

Two independent solvers (Z3 and cvc5) read the same formula. A YES drawing is then
checked by the referee; a NO is trusted only if both solvers say NO.

Run: python3 oct_exact.py jeffs_96_codes.json K SECONDS [ids...]
"""
import json, os, sys, time
from fractions import Fraction as F
from oct_search import grid_points
from oct_checker import FORMS, check

RNG = lambda K: {"x": (0, K), "y": (0, K), "x+y": (0, 2 * K), "x-y": (-K, K)}


def fval(form, p):
    x, y = p
    return {"x": x, "y": y, "x+y": x + y, "x-y": x - y}[form]


def decide(codewords, K, solver="z3", timeout_s=600):
    if solver == "z3":
        import z3 as S
    else:
        import cvc5.pythonic as S
    code = {frozenset(c) for c in codewords} | {frozenset()}
    neurons = sorted(set().union(*code))
    lo = {(n, f): S.Int(f"lo_{n}_{f.replace('+','p').replace('-','m')}") for n in neurons for f in FORMS}
    hi = {(n, f): S.Int(f"hi_{n}_{f.replace('+','p').replace('-','m')}") for n in neurons for f in FORMS}
    s = S.Solver()
    if solver == "z3":
        s.set("timeout", int(timeout_s * 1000))
    else:
        s.set("tlimit", int(timeout_s * 1000))
    for n in neurons:
        for f in FORMS:
            a, b = RNG(K)[f]
            s.add(lo[n, f] >= a, lo[n, f] < hi[n, f], hi[n, f] <= b)

    pts = grid_points(K)
    # Grid values are multiples of 1/12; compare 12*value with 12*limit to stay in integers.
    inside = {}
    for i, p in enumerate(pts):
        for n in neurons:
            conds = []
            for f in FORMS:
                v6 = fval(f, p) * 12
                assert v6.denominator == 1
                v6 = int(v6)
                conds += [12 * lo[n, f] < v6, v6 < 12 * hi[n, f]]
            b = S.Bool(f"in_{n}_{i}")
            s.add(b == S.And(*conds))
            inside[n, i] = b

    def shows(c, i):
        return S.And(*[inside[n, i] if n in c else S.Not(inside[n, i]) for n in neurons])

    for i in range(len(pts)):                       # nothing forbidden anywhere
        s.add(S.Or(*[shows(c, i) for c in code]))
    for c in code:                                  # every codeword appears somewhere
        if c:
            s.add(S.Or(*[shows(c, i) for i in range(len(pts))]))

    r = s.check()
    if r == S.unsat:
        return "UNSAT", None
    if r == S.sat:
        m = s.model()
        val = lambda v: int(str(m.eval(v)))
        cert = {str(n): {f: [val(lo[n, f]), val(hi[n, f])] for f in FORMS} for n in neurons}
        return "SAT", cert
    return "UNKNOWN", None


def main():
    path, K, t = sys.argv[1], int(sys.argv[2]), float(sys.argv[3])
    only = sys.argv[4:]
    codes = {c["id"]: c for c in json.load(open(path))["codes"]}
    os.makedirs("exact_results", exist_ok=True)
    for cid in only:
        c = codes[cid]
        out = {"id": cid, "K": K}
        for solver in os.environ.get("SOLVERS", "z3").split(","):
            t0 = time.time()
            r, cert = decide(c["codewords"], K, solver, t)
            out[solver] = {"result": r, "seconds": round(time.time() - t0, 1)}
            if r == "SAT":
                assert check(c["codewords"], cert)[0], f"{cid}: {solver} drawing failed the referee"
                out["drawing"] = cert
                break                                # a checked drawing needs no second opinion
        json.dump(out, open(f"exact_results/{cid}_K{K}.json", "w"), indent=1)
        print(cid, f"K={K}", {s: out[s]["result"] for s in ("z3", "cvc5") if s in out},
              {s: out[s]["seconds"] for s in ("z3", "cvc5") if s in out}, flush=True)


if __name__ == "__main__":
    main()
