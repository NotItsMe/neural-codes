"""Tests for the morphism (image) checker. Run: python3 test_morph_check.py"""
import json
from neuralcodes import make_code, parse_short, has_local_obstruction
from morph_check import trunk, all_trunks, image, find_bad_image, verify_cert

def ok(name, cond):
    print(("PASS  " if cond else "FAIL  ") + name)
    assert cond, name

# 1. Trunk of sigma = codewords containing sigma.
C = make_code([[1, 2], [2, 3], [1], [3]])
ok("trunk of {1}", trunk(C, {1}) == {frozenset({1, 2}), frozenset({1})})
ok("trunk of a non-face is empty", trunk(C, {1, 3}) == frozenset())

# 2. Image using trunks Tk(1), Tk(2) is the same as forgetting neuron 3.
im = image(C, [trunk(C, {1}), trunk(C, {2})])
ok("restriction image", im == make_code([[1, 2], [2], [1]]))

# 3. A code with its own local obstruction: identity image finds it.
#    {12, 23, 1, 3}: link of 2 is two points -> obstruction.
cert = find_bad_image(C, max_neurons=3)
ok("finds obstruction in {12,23,1,3}", cert is not None)
ok("its certificate verifies", verify_cert(C, cert))

# 4. Jeffs' C0 is MINIMALLY non-convex (Thm 5.10, Morphisms of Neural Codes):
#    every image other than itself is convex, so no image may have an obstruction.
C0 = make_code(parse_short(["3456", "123", "145", "256", "45", "56", "1", "2", "3"]))
ok("C0 itself has no local obstruction", not has_local_obstruction(C0))
ok("no image of C0 has an obstruction (no false alarms)", find_bad_image(C0, max_neurons=6) is None)

# 5. A tampered certificate must be rejected.
bad = dict(cert); bad["obstruction_face"] = [1]
ok("tampered certificate rejected", not verify_cert(C, bad))

# 6. Convex codes cannot have a non-convex image (Thm 1.3). Run on a few of my
#    proven-convex codes: the checker must find nothing.
codes = {c["id"]: c for c in json.load(open("jeffs_96_codes.json"))["codes"]}
for cid in ["C5-002", "C5-004", "C5-022"]:
    ok(f"{cid} (proven convex) has no bad image",
       find_bad_image(make_code(codes[cid]["codewords"]), max_neurons=5) is None)

print("\nAll morphism checker tests passed.")
