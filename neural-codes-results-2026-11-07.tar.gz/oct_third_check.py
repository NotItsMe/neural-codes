"""
oct_third_check.py - the dumbest possible check, on purpose.
Every saved octagon drawing uses whole-number limits, so every edge line is
x=k, y=k, x+y=k or x-y=k for whole k. Every vertex, edge piece and face of such a
drawing contains a point whose coordinates are multiples of 1/12. So I just test
EVERY point (a/12, b/12) in a box around the drawing and list the patterns I see.
Run: python3 oct_third_check.py jeffs_96_codes.json
"""
import glob, json, sys
from fractions import Fraction as F


def patterns(regions, lo=-1, hi=7, step=12):
    vals = {"x": lambda x, y: x, "y": lambda x, y: y,
            "x+y": lambda x, y: x + y, "x-y": lambda x, y: x - y}
    regs = {int(n): {f: (F(a), F(b)) for f, (a, b) in r.items()} for n, r in regions.items()}
    seen = set()
    for i in range(lo * step, hi * step + 1):
        for j in range(lo * step, hi * step + 1):
            x, y = F(i, step), F(j, step)
            seen.add(frozenset(n for n, r in regs.items()
                               if all(a < vals[f](x, y) < b for f, (a, b) in r.items())))
    return seen


if __name__ == "__main__":
    codes = {c["id"]: c for c in json.load(open(sys.argv[1]))["codes"]}
    for path in sorted(glob.glob("certificates/*.json")):
        cert = json.load(open(path))
        if "regions" not in cert:
            continue
        target = {frozenset(w) for w in codes[cert["id"]]["codewords"]} | {frozenset()}
        bounds = [v for r in cert["regions"].values() for f in ("x", "y") for v in r[f]]
        got = patterns(cert["regions"], lo=min(bounds) - 1, hi=max(bounds) + 1)
        print(cert["id"], "THIRD CHECK:", "PASS" if got == target else
              f"FAIL missing {sorted(map(sorted, target - got))} extra {sorted(map(sorted, got - target))}")
