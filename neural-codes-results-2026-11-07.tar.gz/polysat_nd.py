"""
polysat_nd.py - faster YES-hunt for drawings in any dimension (built for 3D).

Same regions as poly3d.py (lo < a.p < hi for each allowed direction a, whole-number limits), but the
limits are found by a SAT solver (CaDiCaL through pysat, order encoding as in poly.py) instead of Z3
integer arithmetic. Loop:
  1. points = a starting lattice (cube centers) ; SAT: every point shows an allowed pattern and every
     codeword shows at some point.
  2. decode the limits, ask the EXACT referee (poly3d.check, Z3 rationals per pattern).
  3. if the referee finds a forbidden pattern somewhere, add that exact point and go again.
A YES always passed the exact referee. A NO ("NONE_ON_GRID") is also sound: any real drawing with
these limits satisfies every constraint at every point I ever add, so no drawing has these limits.
"""
import json, math, os, sys, time
from fractions import Fraction as F
from itertools import count, product
from pysat.solvers import Solver
from poly3d import check, key, dot, DIAG3, AX3
from itertools import combinations as _comb


def diag_dirs(dim):
    """axes plus every e_i + e_j and e_i - e_j (dim=3 gives DIAG3's 9 directions)."""
    ax = [tuple(int(i == k) for i in range(dim)) for k in range(dim)]
    out = list(ax)
    for i, j in _comb(range(dim), 2):
        for s in (1, -1):
            out.append(tuple(1 if k == i else s if k == j else 0 for k in range(dim)))
    return out


def rng(d, K):
    return sum(min(0, a * K) for a in d), sum(max(0, a * K) for a in d)


class Enc:
    def __init__(self, codewords, dirs, K):
        self.code = {frozenset(c) for c in codewords} | {frozenset()}
        self.words = [c for c in self.code if c]
        self.neurons = sorted(set().union(*self.code))
        self.dirs, self.K = dirs, K
        self.nv = count(1)
        self.s = Solver(name="cd19")
        self.le = {}
        for n in self.neurons:
            for d in dirs:
                a, b = rng(d, K)
                for kind in ("lo", "hi"):
                    self.le[kind, n, d] = {t: next(self.nv) for t in range(a, b)}
                    for t in range(a, b - 1):
                        self.add([-self.le[kind, n, d][t], self.le[kind, n, d][t + 1]])
                for t in range(a, b + 1):          # hi <= t  ->  lo <= t-1
                    self.add([self.neg(self.LE("hi", n, d, t)), self.LE("lo", n, d, t - 1)])
        self.shows = {w: [] for w in self.words}   # codeword -> list of "shows here" vars
        self.npts = 0

    T, Fa = "T", "F"

    def neg(self, l):
        return self.Fa if l == self.T else self.T if l == self.Fa else -l

    def add(self, lits):
        if self.T in lits:
            return
        lits = [l for l in lits if l != self.Fa]
        assert lits, "empty clause"
        self.s.add_clause(lits)

    def LE(self, kind, n, d, t):
        a, b = rng(d, self.K)
        return self.Fa if t < a else self.T if t >= b else self.le[kind, n, d][t]

    def add_point(self, p):
        self.npts += 1
        ins = {}
        for n in self.neurons:
            lits = []
            for d in self.dirs:
                v = dot(d, p)
                lits += [self.LE("lo", n, d, math.ceil(v) - 1), self.neg(self.LE("hi", n, d, math.floor(v)))]
            if self.Fa in lits:
                ins[n] = self.Fa
                continue
            lits = [l for l in lits if l != self.T]
            if not lits:
                ins[n] = self.T
                continue
            b = next(self.nv)
            for l in lits:
                self.add([-b, l])
            self.add([b] + [self.neg(l) for l in lits])
            ins[n] = b
        row = []
        for c in self.code:
            need = [ins[n] if n in c else self.neg(ins[n]) for n in self.neurons]
            if self.Fa in need:
                continue
            sv = next(self.nv)
            for l in need:
                self.add([-sv, l])
            row.append(sv)
            if c:
                self.shows[c].append(sv)
        self.add(row)

    def solve(self):
        sel = next(self.nv)                        # this round's "every codeword shows" clauses
        for w in self.words:
            self.add([-sel] + self.shows[w])
        if not self.s.solve(assumptions=[sel]):
            return None
        pos = {x for x in self.s.get_model() if x > 0}
        tv = lambda l: l == self.T or (l != self.Fa and l in pos)
        cert = {}
        for n in self.neurons:
            cert[str(n)] = {}
            for d in self.dirs:
                a, b = rng(d, self.K)
                lo = next(t for t in range(a, b + 1) if tv(self.LE("lo", n, d, t)))
                hi = next(t for t in range(a, b + 1) if tv(self.LE("hi", n, d, t)))
                cert[str(n)][key(d)] = [lo, hi]
        return cert


def search(codewords, dirs, K, timeout_s, step=F(1, 2)):
    dim = len(dirs[0])
    e = Enc(codewords, dirs, K)
    vals = []
    x = step
    while x < K:
        vals.append(x)
        x += 2 * step
    for p in product(vals, repeat=dim):
        e.add_point(p)
    t0, rounds = time.time(), 0
    while time.time() - t0 < timeout_s:
        rounds += 1
        cert = e.solve()
        if cert is None:
            return "NONE_ON_GRID", None, rounds
        ok, missing, extra, found = check(codewords, cert, dirs)
        if ok:
            return "SOLVED", cert, rounds
        assert not missing, "a codeword shown at a point cannot be missing"
        for pat in extra:
            e.add_point(found[pat])
    return "TIMEOUT", None, rounds


def main():
    path, K, t = sys.argv[1], int(sys.argv[2]), float(sys.argv[3])
    codes = {c["id"]: c for c in json.load(open(path))["codes"]}
    os.makedirs("poly3d_results", exist_ok=True)
    for cid in sys.argv[4:]:
        dim = int(os.environ.get("DIM", "3"))
        out_path = f"poly3d_results/{cid}_K{K}.json" if dim == 3 else f"poly3d_results/{cid}_D{dim}_K{K}.json"
        if os.path.exists(out_path) and json.load(open(out_path))["result"] in ("SOLVED", "NONE_ON_GRID"):
            continue
        t0 = time.time()
        DIRS = diag_dirs(int(os.environ.get("DIM", "3")))
        r, cert, rounds = search(codes[cid]["codewords"], DIRS, K, t)
        out = {"id": cid, "directions": [list(d) for d in DIRS], "K": K, "result": r,
               "rounds": rounds, "seconds": round(time.time() - t0, 1)}
        if cert:
            assert check(codes[cid]["codewords"], cert, DIRS)[0]
            out["drawing"] = cert
        json.dump(out, open(out_path, "w"), indent=1)
        print(cid, f"{dim}D K={K}", r, rounds, "rounds", out["seconds"], "s", flush=True)


if __name__ == "__main__":
    main()
